import { PocketIc } from "@dfinity/pic";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { idlFactory } from "../../src/frontend/src/declarations/backend.did.js";
import type { _SERVICE } from "../../src/frontend/src/declarations/backend.did";

const PIC_URL = process.env.POCKET_IC_URL ?? "";
const BACKEND_WASM = process.env.BACKEND_WASM ?? "";

let pic: PocketIc | undefined;
let actor: _SERVICE;

beforeAll(async () => {
  pic = await PocketIc.create(PIC_URL);
  ({ actor } = await pic.setupCanister<_SERVICE>({ idlFactory, wasm: BACKEND_WASM }));
});

afterAll(async () => {
  await pic?.tearDown();
});

describe("MyScout backend public API", () => {
  it("returns the seeded catalog instead of trapping", async () => {
    const catalog = await actor.getCatalog();
    expect(Array.isArray(catalog)).toBe(true);
    expect(catalog.length).toBeGreaterThan(0);
  });

  it("returns full opportunity fields for the seeded catalog", async () => {
    const catalog = await actor.getCatalog();
    const first = catalog[0];
    expect(first).toBeDefined();
    expect(first.name.length).toBeGreaterThan(0);
    expect(first.organizer.length).toBeGreaterThan(0);
    expect(first.factorRatings).toBeDefined();
  });

  it("looks up a single opportunity by id", async () => {
    const catalog = await actor.getCatalog();
    const id = catalog[0].id;
    const result = await actor.getOpportunity(id);
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe(id);
  });

  it("returns the 19 opportunity categories", async () => {
    const categories = await actor.getCategories();
    expect(categories.length).toBe(19);
  });

  it("searches opportunities by keyword", async () => {
    const catalog = await actor.getCatalog();
    const keyword = catalog[0].name.slice(0, 4);
    const results = await actor.searchOpportunities(keyword);
    expect(Array.isArray(results)).toBe(true);
  });

  it("filters opportunities without trapping", async () => {
    const results = await actor.filterOpportunities({
      category: [],
      cost: [],
      distance: [],
      status: [],
    });
    expect(Array.isArray(results)).toBe(true);
  });

  it("recommends opportunities for each mode without trapping", async () => {
    const modes = [
      { highestRated: null },
      { closingSoon: null },
      { closest: null },
      { university: null },
      { bestValue: null },
      { skills: null },
    ] as const;
    for (const mode of modes) {
      const results = await actor.recommend(mode);
      expect(Array.isArray(results)).toBe(true);
    }
  });

  it("returns a rating explanation with 10 factors for a known opportunity", async () => {
    const catalog = await actor.getCatalog();
    const id = catalog[0].id;
    const explanation = await actor.getRatingExplanation(id);
    expect(explanation).toHaveLength(1);
    expect(explanation[0].overall).toBeGreaterThan(0);
    expect(explanation[0].factors.length).toBe(10);
  });
});
