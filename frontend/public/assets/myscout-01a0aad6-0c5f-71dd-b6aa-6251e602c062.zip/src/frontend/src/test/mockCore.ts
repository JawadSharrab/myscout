import { vi } from "vitest";
import { type MockActor, createMockActor } from "./mockBackend";

/**
 * Shared, configurable mocks for the `@caffeineai/core-infrastructure` hooks
 * that the app's data layer depends on (`useActor`, `useInternetIdentity`).
 * Tests import `setAuthState` / `setMockActor` to control behavior.
 */

export const coreMock = {
  actor: createMockActor(),
  isAuthenticated: false,
  isInitializing: false,
  isLoggingIn: false,
  login: vi.fn(async () => undefined),
  clear: vi.fn(async () => undefined),
};

export function setMockActor(actor: MockActor) {
  coreMock.actor = actor;
}

export function setAuthState(state: {
  isAuthenticated?: boolean;
  isInitializing?: boolean;
  isLoggingIn?: boolean;
}) {
  Object.assign(coreMock, state);
}

export function resetCoreMock() {
  coreMock.actor = createMockActor();
  coreMock.isAuthenticated = false;
  coreMock.isInitializing = false;
  coreMock.isLoggingIn = false;
  coreMock.login.mockClear();
  coreMock.clear.mockClear();
}

vi.mock("@caffeineai/core-infrastructure", () => ({
  useActor: () => ({
    actor: coreMock.actor,
    isFetching: false,
  }),
  useInternetIdentity: () => ({
    isAuthenticated: coreMock.isAuthenticated,
    isInitializing: coreMock.isInitializing,
    isLoggingIn: coreMock.isLoggingIn,
    login: coreMock.login,
    clear: coreMock.clear,
  }),
}));
