import "@testing-library/jest-dom/vitest";
import { cleanup, configure } from "@testing-library/react";
import { afterEach, vi } from "vitest";
import "./mockCore";

// jsdom does not implement `window.matchMedia`, which `next-themes`'s
// ThemeProvider calls during render to resolve the system color scheme. Stub
// the minimal surface the app uses so the provider mounts in tests.
if (typeof window !== "undefined" && !window.matchMedia) {
  window.matchMedia = (query: string) =>
    ({
      matches: false,
      media: query,
      onchange: null,
      addListener: () => undefined,
      removeListener: () => undefined,
      addEventListener: () => undefined,
      removeEventListener: () => undefined,
      dispatchEvent: () => false,
    }) as MediaQueryList;
}

// jsdom's File lacks `arrayBuffer()`, which the Create page uses to read an
// uploaded image before wrapping it in an ExternalBlob.
if (typeof File !== "undefined" && !File.prototype.arrayBuffer) {
  File.prototype.arrayBuffer = function arrayBuffer() {
    return new Promise<ArrayBuffer>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as ArrayBuffer);
      reader.readAsArrayBuffer(this);
    });
  };
}

// Radix Select's pointer handling calls these pointer-capture methods, which
// jsdom's synthetic events do not implement. Stub them so opening the category
// select does not throw an unhandled error.
if (typeof Element !== "undefined") {
  Element.prototype.hasPointerCapture ??= () => false;
  Element.prototype.setPointerCapture ??= () => undefined;
  Element.prototype.releasePointerCapture ??= () => undefined;
  // Radix Select scrolls the highlighted option into view when the list opens.
  Element.prototype.scrollIntoView ??= () => undefined;
}

// The generated backend wrapper imports `ExternalBlob` from
// `@caffeineai/object-storage`, whose dist entry has a subpath that does not
// resolve under the test bundler. The frontend never uploads for real in
// tests, so mock out the class with the small surface the Create page uses
// (`fromBytes` + `withUploadProgress`).
vi.mock("@caffeineai/object-storage", () => ({
  ExternalBlob: class ExternalBlob {
    directURL = "https://mock.example/blob";
    contentType?: string;
    filename?: string;
    constructor(contentType?: string, filename?: string) {
      this.contentType = contentType;
      this.filename = filename;
    }
    static fromBytes(
      _blob: Uint8Array,
      contentType?: string,
      filename?: string,
    ) {
      return new ExternalBlob(contentType, filename);
    }
    withUploadProgress(_onProgress: (percentage: number) => void) {
      return this;
    }
  },
}));

// The generated app uses `data-ocid` for its test selectors.
configure({ testIdAttribute: "data-ocid" });

// Ensure a clean DOM between tests. The app's router schedules async
// transitions that can otherwise leak rendered content across tests.
afterEach(() => {
  cleanup();
  document.body.innerHTML = "";
  window.history.replaceState({}, "", "/");
});
