import type { Category, Opportunity, OrganizerProfile } from "@/backend";
import type { _SERVICE } from "@/declarations/backend.did";
import { vi } from "vitest";
import { mockCategories, mockOpportunities } from "./fixtures";

/**
 * Builds a typed mock actor implementing the backend public API surface the
 * frontend consumes. All methods are vi.fn() so tests can assert calls and
 * override return values per-test.
 */
export function createMockActor(
  overrides: Partial<Record<keyof _SERVICE, unknown>> = {},
) {
  const actor = {
    getCatalog: vi.fn(async (): Promise<Opportunity[]> => mockOpportunities),
    getCategories: vi.fn(async () => mockCategories),
    getOpportunity: vi.fn(
      async (id: bigint) => mockOpportunities.find((o) => o.id === id) ?? null,
    ),
    getRatingExplanation: vi.fn(async () => ({
      overall: 4.3,
      factors: [
        { name: "University application value", weight: 0.2, rating: 4.5 },
        { name: "Skill development", weight: 0.15, rating: 4.5 },
      ],
    })),
    searchOpportunities: vi.fn(async () => [] as Opportunity[]),
    filterOpportunities: vi.fn(async () => [] as Opportunity[]),
    recommend: vi.fn(async () => [] as Opportunity[]),
    getSavedOpportunities: vi.fn(async () => [] as Opportunity[]),
    saveOpportunity: vi.fn(async () => undefined),
    unsaveOpportunity: vi.fn(async () => undefined),
    getInterests: vi.fn(async () => [] as Category[]),
    setInterests: vi.fn(async () => undefined),
    recommendByInterests: vi.fn(async () => [] as Opportunity[]),
    filterByInterests: vi.fn(async () => [] as Opportunity[]),
    deleteAccount: vi.fn(async () => undefined),
    createOrganizerAccount: vi.fn(async () => undefined),
    getCallerOrganizerProfile: vi.fn(
      async () => null as OrganizerProfile | null,
    ),
    listOpportunity: vi.fn(async () => 100n),
    getOpportunityImages: vi.fn(async () => [] as Uint8Array[]),
    ...overrides,
  } as unknown as _SERVICE;
  return actor;
}

export type MockActor = ReturnType<typeof createMockActor>;
