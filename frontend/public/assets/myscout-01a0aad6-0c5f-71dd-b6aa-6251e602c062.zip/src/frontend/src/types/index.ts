// Shared MyScout types re-exported from the generated backend contract.
// Enums are values (used in switches and as `Category.scholarship`); interfaces
// are types. Page tasks import these from `@/types`.

export type {
  ExternalBlob,
  FactorRatings,
  FactorScore,
  Marker,
  NewOpportunity,
  Opportunity,
  OpportunityFilter,
  OpportunityId,
  OrganizerProfile,
  RatingExplanation,
  Timestamp,
} from "@/backend";

export {
  Category,
  CostFilter,
  RecommendationMode,
  Status,
  UserRole,
} from "@/backend";
