import { InterestsPicker } from "@/components/InterestsPicker";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { useAccount } from "@/hooks/useAccount";
import { useDeleteAccount } from "@/hooks/useQueries";
import type { Category } from "@/types";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  LogOut,
  Settings2,
  Sparkles,
  Trash2,
  User,
} from "lucide-react";
import { useState } from "react";

function categoryLabel(cat: Category): string {
  return cat.charAt(0).toUpperCase() + cat.slice(1);
}

/**
 * Account page: a compact, non-scroll-heavy surface where the signed-in user
 * edits their interests, signs out, or deletes their account.
 */
export function AccountPage() {
  const { clear, isAuthenticated } = useInternetIdentity();
  const { interests, interestsLoading } = useAccount();
  const queryClient = useQueryClient();
  const deleteMutation = useDeleteAccount();
  const isDeletingAccount = deleteMutation.isPending;

  const [pickerOpen, setPickerOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [confirmation, setConfirmation] = useState("");
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const handleSignOut = () => {
    clear();
  };

  const openDeleteDialog = () => {
    setDeleteError(null);
    setConfirmation("");
    setDeleteOpen(true);
  };

  const handleDelete = () => {
    if (confirmation.trim() !== "DELETE") return;
    deleteMutation.mutate(confirmation.trim(), {
      onSuccess: () => {
        queryClient.clear();
        clear();
        setDeleteOpen(false);
        setConfirmation("");
        setDeleteError(null);
      },
      onError: (err) => {
        setDeleteError(
          err instanceof Error
            ? err.message
            : "Something went wrong while deleting your account. Please try again.",
        );
      },
    });
  };

  return (
    <div className="mx-auto max-w-3xl px-5 py-10 md:px-8">
      <header className="mb-8">
        <h1 className="font-display text-3xl font-bold tracking-tight text-foreground">
          Account
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage your personalization, session, and account settings.
        </p>
      </header>

      <div className="flex flex-col gap-6">
        {/* Personalization */}
        <section
          className="rounded-2xl border border-border bg-card p-6 shadow-subtle"
          data-ocid="account_personalization_section"
        >
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-accent/15 text-accent">
                <Sparkles className="size-5" />
              </span>
              <div>
                <h2 className="font-display text-lg font-bold text-foreground">
                  Interests
                </h2>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  These personalize your recommendations across MyScout.
                </p>
              </div>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setPickerOpen(true)}
              data-ocid="account_edit_interests_button"
            >
              <Settings2 className="size-4" />
              Edit
            </Button>
          </div>

          <div className="mt-5">
            {interestsLoading ? (
              <p
                className="text-sm text-muted-foreground"
                data-ocid="account_interests_loading"
              >
                Loading your interests…
              </p>
            ) : interests.length === 0 ? (
              <p
                className="text-sm text-muted-foreground"
                data-ocid="account_interests_empty"
              >
                You haven't picked any interests yet. Choose a few to get
                personalized recommendations.
              </p>
            ) : (
              <div
                className="flex flex-wrap gap-2"
                data-ocid="account_interests_list"
              >
                {interests.map((cat) => (
                  <span
                    key={cat}
                    className="inline-flex items-center rounded-full border border-accent/30 bg-accent/10 px-3 py-1 text-sm font-semibold text-foreground"
                    data-ocid={`account_interest.${cat}`}
                  >
                    {categoryLabel(cat)}
                  </span>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Session */}
        <section
          className="rounded-2xl border border-border bg-card p-6 shadow-subtle"
          data-ocid="account_session_section"
        >
          <div className="flex items-start gap-3">
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground">
              <User className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-lg font-bold text-foreground">
                Session
              </h2>
              <p className="mt-0.5 text-sm text-muted-foreground">
                You're signed in. Sign out to return to the signed-out
                experience.
              </p>
            </div>
          </div>
          <div className="mt-5">
            <Button
              type="button"
              variant="outline"
              onClick={handleSignOut}
              disabled={!isAuthenticated}
              data-ocid="account_sign_out_button"
            >
              <LogOut className="size-4" />
              Sign out
            </Button>
          </div>
        </section>

        {/* Danger zone */}
        <section
          className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6"
          data-ocid="account_danger_section"
        >
          <div className="flex items-start gap-3">
            <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-destructive/15 text-destructive">
              <Trash2 className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-lg font-bold text-foreground">
                Delete account
              </h2>
              <p className="mt-0.5 text-sm text-muted-foreground">
                Permanently wipes your saved opportunities, interests, and
                organizer profile. This cannot be undone.
              </p>
            </div>
          </div>
          <div className="mt-5">
            <Button
              type="button"
              variant="destructive"
              onClick={openDeleteDialog}
              data-ocid="account_delete_button"
            >
              <Trash2 className="size-4" />
              Delete account
            </Button>
          </div>
        </section>
      </div>

      <InterestsPicker
        open={pickerOpen}
        onOpenChange={setPickerOpen}
        mode="edit"
      />

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent data-ocid="account_delete_dialog">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete your account?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently wipes your saved opportunities, interests, and
              organizer profile. This cannot be undone. Type{" "}
              <strong>DELETE</strong> to confirm.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <input
            type="text"
            value={confirmation}
            onChange={(e) => setConfirmation(e.target.value)}
            placeholder="Type DELETE to confirm"
            aria-label="Type DELETE to confirm"
            className="h-10 rounded-md border border-input bg-background px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
            data-ocid="account_delete_confirmation_input"
          />
          {deleteError && (
            <p
              role="alert"
              className="text-sm font-medium text-destructive"
              data-ocid="account_delete_error_message"
            >
              {deleteError}
            </p>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel
              onClick={() => setConfirmation("")}
              data-ocid="account_delete_cancel_button"
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={confirmation.trim() !== "DELETE" || isDeletingAccount}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-ocid="account_delete_confirm_button"
            >
              <AlertTriangle className="size-4" />
              {isDeletingAccount ? "Deleting…" : "Delete account"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
