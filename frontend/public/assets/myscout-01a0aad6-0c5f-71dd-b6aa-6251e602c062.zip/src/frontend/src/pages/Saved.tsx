import { SaveButton } from "@/components/SaveButton";
import { SignInPrompt } from "@/components/SignInPrompt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetSavedOpportunities } from "@/hooks/useQueries";
import { useSaved } from "@/hooks/useSaved";
import { getOverallScore, getScoreColor } from "@/lib/scoring";
import type { Opportunity, Timestamp } from "@/types";
import type { Category } from "@/types";
import { Link } from "@tanstack/react-router";
import {
  Bookmark,
  CalendarDays,
  Compass,
  MapPin,
  Sparkles,
  Wallet,
} from "lucide-react";
import { useState } from "react";

function formatDate(timestamp: Timestamp): string {
  const date = new Date(Number(timestamp / 1_000_000n));
  if (Number.isNaN(date.getTime())) return "Date TBA";
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function categoryLabel(category: Category): string {
  return category.charAt(0).toUpperCase() + category.slice(1);
}

function SavedCard({
  opportunity,
  index,
}: { opportunity: Opportunity; index: number }) {
  const score = getOverallScore(opportunity);
  const scoreColor = getScoreColor(score);

  return (
    <Card
      className="group gap-0 overflow-hidden p-0 transition-smooth hover:-translate-y-0.5 hover:shadow-md"
      data-ocid={`saved_card.${index}`}
    >
      <CardContent className="flex flex-col gap-4 px-5 py-5">
        <div className="flex items-start justify-between gap-3">
          <Badge variant="secondary" className="capitalize">
            {categoryLabel(opportunity.category)}
          </Badge>
          <span
            className={`grid size-11 shrink-0 place-items-center rounded-full border font-display text-base font-bold ${scoreColor} ${
              score >= 4.5
                ? "border-accent/30 bg-accent/10"
                : score >= 4.0
                  ? "border-primary/30 bg-primary/10"
                  : "border-destructive/30 bg-destructive/10"
            }`}
            title={`Overall score ${score.toFixed(1)} / 5`}
          >
            {score.toFixed(1)}
          </span>
        </div>

        <div className="min-w-0">
          <Link
            to="/opportunity/$id"
            params={{ id: opportunity.id.toString() }}
            className="font-display text-lg font-bold leading-snug text-foreground transition-colors hover:text-primary"
            data-ocid={`saved_card_link.${index}`}
          >
            <span className="line-clamp-2">{opportunity.name}</span>
          </Link>
          <p className="mt-1 text-sm font-medium text-muted-foreground">
            {opportunity.organizer}
          </p>
        </div>

        <dl className="grid grid-cols-2 gap-x-3 gap-y-2 border-t border-border pt-4 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <CalendarDays className="size-4 shrink-0 text-accent" />
            <dd className="min-w-0 truncate">{formatDate(opportunity.date)}</dd>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Wallet className="size-4 shrink-0 text-accent" />
            <dd className="min-w-0 truncate">{opportunity.fee}</dd>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="size-4 shrink-0 text-accent" />
            <dd className="min-w-0 truncate">{opportunity.distanceKm} km</dd>
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Compass className="size-4 shrink-0 text-accent" />
            <dd className="min-w-0 truncate">{opportunity.location}</dd>
          </div>
        </dl>

        <div className="flex items-center justify-between gap-3 border-t border-border pt-4">
          <Link
            to="/opportunity/$id"
            params={{ id: opportunity.id.toString() }}
            className="text-sm font-semibold text-primary transition-colors hover:text-primary/80"
            data-ocid={`saved_view_link.${index}`}
          >
            View details
          </Link>
          <SaveButton
            id={opportunity.id}
            name={opportunity.name}
            variant="icon"
          />
        </div>
      </CardContent>
    </Card>
  );
}

function SavedSkeleton() {
  return (
    <div
      className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
      data-ocid="saved_loading_state"
    >
      {Array.from({ length: 6 }, (_, i) => `skeleton-${i}`).map((id) => (
        <Card key={id} className="gap-0 p-0">
          <CardContent className="flex flex-col gap-4 px-5 py-5">
            <div className="flex items-start justify-between gap-3">
              <Skeleton className="h-6 w-24" />
              <Skeleton className="size-11 rounded-full" />
            </div>
            <div className="space-y-2">
              <Skeleton className="h-5 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
            <div className="grid grid-cols-2 gap-3 border-t border-border pt-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export function SavedPage() {
  const { isAuthenticated, savedCount } = useSaved();
  const { data: savedOpportunities = [], isLoading } =
    useGetSavedOpportunities();
  const [promptOpen, setPromptOpen] = useState(false);

  return (
    <div
      className="mx-auto max-w-7xl px-5 py-10 md:px-8 md:py-14"
      data-ocid="saved_page"
    >
      <header className="mb-8 max-w-2xl">
        <p className="mb-2 text-xs font-semibold tracking-[0.17em] text-accent uppercase">
          MyScout · Your shortlist
        </p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Saved opportunities.
        </h1>
        <p className="mt-3 text-muted-foreground">
          The opportunities you want to come back to. Saved to your account so
          they follow you across visits.
        </p>
      </header>

      {!isAuthenticated ? (
        <Card
          className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
          data-ocid="saved_sign_in_state"
        >
          <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
            <Bookmark className="size-7" />
          </span>
          <div className="space-y-1">
            <h2 className="font-display text-xl font-bold text-foreground">
              Sign in to see your shortlist
            </h2>
            <p className="text-sm text-muted-foreground">
              Your saved opportunities live with your account. Sign in to keep
              your shortlist across visits and come back to it later.
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setPromptOpen(true)}
            className="mt-1"
            data-ocid="saved_sign_in_button"
          >
            <Bookmark className="size-4" />
            Sign in to save
          </Button>
          <SignInPrompt
            open={promptOpen}
            onOpenChange={setPromptOpen}
            title="Sign in to save"
            description="Create a MyScout account to keep your shortlist across visits and come back to it later."
          />
        </Card>
      ) : isLoading ? (
        <SavedSkeleton />
      ) : savedOpportunities.length === 0 ? (
        <Card
          className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
          data-ocid="saved_empty_state"
        >
          <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
            <Sparkles className="size-7" />
          </span>
          <div className="space-y-1">
            <h2 className="font-display text-xl font-bold text-foreground">
              Nothing saved yet
            </h2>
            <p className="text-sm text-muted-foreground">
              Tap the bookmark on any opportunity to add it to your shortlist.
              Your saved picks will show up here.
            </p>
          </div>
          <Button
            type="button"
            asChild
            className="mt-1"
            data-ocid="saved_browse_button"
          >
            <Link to="/">
              <Compass className="size-4" />
              Discover opportunities
            </Link>
          </Button>
        </Card>
      ) : (
        <>
          <p className="mb-5 text-sm font-medium text-muted-foreground">
            {savedCount} {savedCount === 1 ? "opportunity" : "opportunities"}{" "}
            saved
          </p>
          <div
            className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
            data-ocid="saved_list"
          >
            {savedOpportunities.map((opportunity, index) => (
              <SavedCard
                key={opportunity.id.toString()}
                opportunity={opportunity}
                index={index}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
