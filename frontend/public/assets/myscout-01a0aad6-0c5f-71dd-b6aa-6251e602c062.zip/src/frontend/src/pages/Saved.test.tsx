import App from "@/App";
import { Category } from "@/backend";
import { mockOpportunities } from "@/test/fixtures";
import { createMockActor } from "@/test/mockBackend";
import { resetCoreMock, setAuthState, setMockActor } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it } from "vitest";

function renderApp(path = "/saved") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

/** Signed-in users with no interests get the first-sign-in picker overlay. */
function signedInActor(overrides: Parameters<typeof createMockActor>[0] = {}) {
  return createMockActor({
    getInterests: async () => [Category.academic],
    ...overrides,
  });
}

describe("Saved page", () => {
  beforeEach(() => {
    resetCoreMock();
  });

  it("shows a clean sign-in-to-save prompt for signed-out users", async () => {
    setAuthState({ isAuthenticated: false });
    renderApp("/saved");

    expect(
      await screen.findByText("Sign in to see your shortlist"),
    ).toBeInTheDocument();
    expect(screen.getByTestId("saved_sign_in_button")).toBeInTheDocument();
  });

  it("shows saved opportunities with an unsave action for signed-in users", async () => {
    setAuthState({ isAuthenticated: true });
    setMockActor(
      signedInActor({
        getSavedOpportunities: async () => [mockOpportunities[0]],
      }),
    );
    renderApp("/saved");

    expect(
      await screen.findByText("Amman Model United Nations"),
    ).toBeInTheDocument();
    expect(screen.getByText("1 opportunity saved")).toBeInTheDocument();

    // Unsave action is present.
    const unsave = screen.getByLabelText(
      "Remove Amman Model United Nations from saved",
    );
    expect(unsave).toBeInTheDocument();
  });

  it("shows an empty state when a signed-in user has nothing saved", async () => {
    setAuthState({ isAuthenticated: true });
    setMockActor(
      signedInActor({
        getSavedOpportunities: async () => [],
      }),
    );
    renderApp("/saved");

    expect(await screen.findByText("Nothing saved yet")).toBeInTheDocument();
  });

  it("unsaves an opportunity from the Saved page", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    const actor = signedInActor({
      getSavedOpportunities: async () => [mockOpportunities[0]],
    });
    setMockActor(actor);
    renderApp("/saved");

    await screen.findByText("Amman Model United Nations");

    await user.click(
      screen.getByLabelText("Remove Amman Model United Nations from saved"),
    );

    await waitFor(() => {
      expect(actor.unsaveOpportunity).toHaveBeenCalledWith(1n);
    });
  });
});
