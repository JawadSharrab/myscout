import App from "@/App";
import { Category } from "@/backend";
import { createMockActor } from "@/test/mockBackend";
import {
  coreMock,
  resetCoreMock,
  setAuthState,
  setMockActor,
} from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it } from "vitest";

function renderApp(path = "/account") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

/** Signed-in users with interests set avoid the first-sign-in picker overlay. */
function signedInActor(overrides: Parameters<typeof createMockActor>[0] = {}) {
  return createMockActor({
    getInterests: async () => [Category.academic],
    ...overrides,
  });
}

describe("Account page", () => {
  beforeEach(() => {
    resetCoreMock();
  });

  it("shows the signed-in user's interests and lets them edit via the picker", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    const actor = signedInActor();
    setMockActor(actor);
    renderApp("/account");

    // The current interest is shown.
    expect(await screen.findByText("Academic")).toBeInTheDocument();

    // Open the edit picker and toggle a second interest, then save.
    await user.click(screen.getByTestId("account_edit_interests_button"));
    const dialog = await screen.findByRole("dialog");
    expect(
      within(dialog).getByRole("heading", { name: "Edit your interests" }),
    ).toBeInTheDocument();

    await user.click(
      within(dialog).getByTestId("interest_option.volunteering"),
    );
    await user.click(within(dialog).getByTestId("interests_save_button"));

    await waitFor(() => {
      expect(actor.setInterests).toHaveBeenCalledWith([
        Category.academic,
        Category.volunteering,
      ]);
    });
  });

  it("signs out from the account page", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    setMockActor(signedInActor());
    renderApp("/account");

    await user.click(await screen.findByTestId("account_sign_out_button"));

    await waitFor(() => {
      expect(coreMock.clear).toHaveBeenCalled();
    });
  });

  it("requires typing DELETE before deleting the account", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    const actor = signedInActor();
    setMockActor(actor);
    renderApp("/account");

    await user.click(await screen.findByTestId("account_delete_button"));
    // The delete confirmation uses Radix AlertDialog, which renders with
    // role="alertdialog" (not "dialog").
    const dialog = await screen.findByRole("alertdialog");

    // Confirm is disabled until the exact confirmation is typed.
    const confirm = within(dialog).getByTestId("account_delete_confirm_button");
    expect(confirm).toBeDisabled();

    await user.type(
      within(dialog).getByTestId("account_delete_confirmation_input"),
      "DELETE",
    );
    expect(confirm).toBeEnabled();

    await user.click(confirm);

    await waitFor(() => {
      expect(actor.deleteAccount).toHaveBeenCalledWith("DELETE");
    });
  });
});

describe("Organizer page", () => {
  beforeEach(() => {
    resetCoreMock();
  });

  it("prompts signed-out users to sign in", async () => {
    setAuthState({ isAuthenticated: false });
    renderApp("/organizer");

    expect(
      await screen.findByText("Sign in to become an organizer"),
    ).toBeInTheDocument();
    expect(screen.getByTestId("organizer_sign_in_button")).toBeInTheDocument();
  });

  it("shows the create form for a signed-in user without a profile", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    const actor = signedInActor({
      getCallerOrganizerProfile: async () => null,
    });
    setMockActor(actor);
    renderApp("/organizer");

    expect(
      await screen.findByText("Create your organizer profile"),
    ).toBeInTheDocument();

    await user.type(screen.getByTestId("organizer_name_input"), "Amira Hassan");
    await user.type(
      screen.getByTestId("organizer_email_input"),
      "amira@example.org",
    );
    await user.type(
      screen.getByTestId("organizer_org_input"),
      "Amman Youth Hub",
    );
    await user.click(screen.getByTestId("organizer_submit_button"));

    await waitFor(() => {
      expect(actor.createOrganizerAccount).toHaveBeenCalledWith({
        name: "Amira Hassan",
        contactEmail: "amira@example.org",
        organization: "Amman Youth Hub",
      });
    });
  });

  it("shows the profile card for a signed-in user with a profile", async () => {
    setAuthState({ isAuthenticated: true });
    setMockActor(
      signedInActor({
        getCallerOrganizerProfile: async () => ({
          name: "Amira Hassan",
          contactEmail: "amira@example.org",
          organization: "Amman Youth Hub",
        }),
      }),
    );
    renderApp("/organizer");

    expect(await screen.findByText("Amira Hassan")).toBeInTheDocument();
    expect(screen.getByText("Amman Youth Hub")).toBeInTheDocument();
    expect(screen.getByText("amira@example.org")).toBeInTheDocument();
    expect(screen.getByTestId("organizer_create_link")).toBeInTheDocument();
  });
});
