import App from "@/App";
import { Category } from "@/backend";
import { createMockActor } from "@/test/mockBackend";
import { resetCoreMock, setAuthState, setMockActor } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it } from "vitest";

function renderApp(path = "/create") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

describe("Create category select", () => {
  beforeEach(() => {
    resetCoreMock();
  });

  it("renders the category select trigger with a placeholder for signed-in organizers", async () => {
    setAuthState({ isAuthenticated: true });
    setMockActor(
      createMockActor({
        getInterests: async () => [Category.academic],
        getCallerOrganizerProfile: async () => ({
          name: "Amira Hassan",
          contactEmail: "amira@example.org",
          organization: "Amman Youth Hub",
        }),
      }),
    );
    renderApp("/create");
    await screen.findByTestId("create_form");

    // The category selector is present and shows its placeholder until a
    // category is chosen. (The Radix Select popover content does not mount in
    // jsdom, so only the trigger is asserted here.)
    const trigger = screen.getByTestId("create_category_select");
    expect(trigger).toBeInTheDocument();
    expect(screen.getByText("Select a category")).toBeInTheDocument();
  });
});
