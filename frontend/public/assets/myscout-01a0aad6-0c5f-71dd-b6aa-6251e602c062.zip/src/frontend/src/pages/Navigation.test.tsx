import App from "@/App";
import { resetCoreMock, setAuthState } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it } from "vitest";

function renderApp(path = "/") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

describe("Primary navigation", () => {
  beforeEach(() => {
    resetCoreMock();
    setAuthState({ isAuthenticated: false });
  });

  it("navigates between Discover, Map, and Saved via the header nav", async () => {
    const user = userEvent.setup();
    renderApp("/");
    // The homepage defaults to the "For you" tab; a signed-out user sees the
    // personalization sign-in state.
    await screen.findByText("Sign in for personalized picks");

    // Map
    await user.click(screen.getByTestId("nav_map"));
    expect(await screen.findByTestId("map_panel")).toBeInTheDocument();

    // Saved
    await user.click(screen.getByTestId("nav_saved"));
    expect(
      await screen.findByText("Sign in to see your shortlist"),
    ).toBeInTheDocument();

    // Back to Discover
    await user.click(screen.getByTestId("nav_discover"));
    expect(
      await screen.findByText("Sign in for personalized picks"),
    ).toBeInTheDocument();
  });
});
