import { SignInPrompt } from "@/components/SignInPrompt";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  useGetCallerOrganizerProfile,
  useGetCategories,
  useListOpportunity,
} from "@/hooks/useQueries";
import type { Category } from "@/types";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { ExternalBlob } from "@caffeineai/object-storage";
import { Link } from "@tanstack/react-router";
import {
  BadgeCheck,
  ImagePlus,
  Loader2,
  Megaphone,
  Trash2,
  UploadCloud,
} from "lucide-react";
import { type FormEvent, useRef, useState } from "react";

interface PendingImage {
  blob: ExternalBlob;
  name: string;
  progress: number;
}

function dateToTimestamp(dateStr: string): bigint {
  const date = new Date(`${dateStr}T00:00:00`);
  return BigInt(date.getTime()) * 1_000_000n;
}

function categoryLabel(category: Category): string {
  return category.charAt(0).toUpperCase() + category.slice(1);
}

function CreateForm() {
  const { data: categories = [] } = useGetCategories();
  const listOpportunity = useListOpportunity();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<Category | "">("");
  const [fee, setFee] = useState("");
  const [duration, setDuration] = useState("");
  const [venue, setVenue] = useState("");
  const [ageRange, setAgeRange] = useState("");
  const [location, setLocation] = useState("");
  const [date, setDate] = useState("");
  const [deadline, setDeadline] = useState("");
  const [registrationUrl, setRegistrationUrl] = useState("");
  const [instagramUrl, setInstagramUrl] = useState("");
  const [images, setImages] = useState<PendingImage[]>([]);
  const [uploading, setUploading] = useState(false);

  const canSubmit =
    name.trim().length > 0 &&
    description.trim().length > 0 &&
    category !== "" &&
    date !== "" &&
    deadline !== "" &&
    images.length > 0 &&
    !uploading;

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    const next: PendingImage[] = [];
    for (const file of Array.from(files)) {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const blob = ExternalBlob.fromBytes(
        bytes,
        file.type,
        file.name,
      ).withUploadProgress((pct) => {
        setImages((prev) =>
          prev.map((img) =>
            img.blob === blob ? { ...img, progress: pct } : img,
          ),
        );
      });
      next.push({ blob, name: file.name, progress: 0 });
    }
    setImages((prev) => [...prev, ...next]);
    setUploading(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const removeImage = (blob: ExternalBlob) => {
    setImages((prev) => prev.filter((img) => img.blob !== blob));
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!canSubmit) return;
    listOpportunity.mutate({
      name: name.trim(),
      description: description.trim(),
      category,
      fee: fee.trim() || "Free",
      duration: duration.trim(),
      venue: venue.trim(),
      ageRange: ageRange.trim(),
      location: location.trim(),
      date: dateToTimestamp(date),
      deadline: dateToTimestamp(deadline),
      registrationUrl: registrationUrl.trim() || undefined,
      instagramUrl: instagramUrl.trim() || undefined,
      images: images.map((img) => img.blob),
    });
  };

  return (
    <Card className="mx-auto max-w-3xl" data-ocid="create_form">
      <CardHeader>
        <CardTitle className="font-display text-xl">
          List an opportunity
        </CardTitle>
        <CardDescription>
          Publish an event or opportunity to the MyScout catalog. Add at least
          one image so it stands out.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <div className="grid gap-5 md:grid-cols-2">
            <div className="flex flex-col gap-2 md:col-span-2">
              <Label htmlFor="create-name">Title</Label>
              <Input
                id="create-name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="e.g. Amman Design Hackathon 2026"
                data-ocid="create_name_input"
              />
            </div>

            <div className="flex flex-col gap-2 md:col-span-2">
              <Label htmlFor="create-description">Description</Label>
              <Textarea
                id="create-description"
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="What is this opportunity, who is it for, and what will participants get out of it?"
                rows={4}
                data-ocid="create_description_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-category">Category</Label>
              <Select
                value={category || undefined}
                onValueChange={(value) => setCategory(value as Category)}
              >
                <SelectTrigger
                  id="create-category"
                  className="w-full"
                  data-ocid="create_category_select"
                >
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {categoryLabel(cat)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-fee">Fee</Label>
              <Input
                id="create-fee"
                value={fee}
                onChange={(event) => setFee(event.target.value)}
                placeholder="Free or e.g. 25 JOD"
                data-ocid="create_fee_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-duration">Duration</Label>
              <Input
                id="create-duration"
                value={duration}
                onChange={(event) => setDuration(event.target.value)}
                placeholder="e.g. 2 days, 3 hours"
                data-ocid="create_duration_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-venue">Venue</Label>
              <Input
                id="create-venue"
                value={venue}
                onChange={(event) => setVenue(event.target.value)}
                placeholder="e.g. Ras El Ain Gallery"
                data-ocid="create_venue_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-location">Location</Label>
              <Input
                id="create-location"
                value={location}
                onChange={(event) => setLocation(event.target.value)}
                placeholder="e.g. Amman, Jordan"
                data-ocid="create_location_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-age-range">Age range</Label>
              <Input
                id="create-age-range"
                value={ageRange}
                onChange={(event) => setAgeRange(event.target.value)}
                placeholder="e.g. 16–24"
                data-ocid="create_age_range_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-date">Event date</Label>
              <Input
                id="create-date"
                type="date"
                value={date}
                onChange={(event) => setDate(event.target.value)}
                data-ocid="create_date_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-deadline">Application deadline</Label>
              <Input
                id="create-deadline"
                type="date"
                value={deadline}
                onChange={(event) => setDeadline(event.target.value)}
                data-ocid="create_deadline_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-registration-url">
                Registration URL{" "}
                <span className="text-muted-foreground">(optional)</span>
              </Label>
              <Input
                id="create-registration-url"
                type="url"
                value={registrationUrl}
                onChange={(event) => setRegistrationUrl(event.target.value)}
                placeholder="https://…"
                data-ocid="create_registration_url_input"
              />
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="create-instagram-url">
                Instagram URL{" "}
                <span className="text-muted-foreground">(optional)</span>
              </Label>
              <Input
                id="create-instagram-url"
                type="url"
                value={instagramUrl}
                onChange={(event) => setInstagramUrl(event.target.value)}
                placeholder="https://instagram.com/…"
                data-ocid="create_instagram_url_input"
              />
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Label>Images</Label>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="flex min-h-28 flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-input bg-muted/30 px-4 py-6 text-center transition-colors hover:border-primary/50 hover:bg-muted/50 disabled:opacity-50"
              data-ocid="create_upload_button"
            >
              <UploadCloud className="size-6 text-accent" />
              <span className="text-sm font-semibold text-foreground">
                {uploading ? "Preparing images…" : "Click to add images"}
              </span>
              <span className="text-xs text-muted-foreground">
                Add at least one image. JPG, PNG, or WebP.
              </span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(event) => void handleFiles(event.target.files)}
              data-ocid="create_file_input"
            />

            {images.length > 0 ? (
              <ul className="flex flex-col gap-3" data-ocid="create_image_list">
                {images.map((img, index) => (
                  <li
                    key={`${img.name}-${index}`}
                    className="flex items-center gap-3 rounded-xl border border-border bg-card px-4 py-3"
                    data-ocid={`create_image_item.${index}`}
                  >
                    <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-accent/10 text-accent">
                      <ImagePlus className="size-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-foreground">
                        {img.name}
                      </p>
                      <Progress
                        value={img.progress}
                        className="mt-2 h-1.5"
                        data-ocid={`create_image_progress.${index}`}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeImage(img.blob)}
                      aria-label={`Remove ${img.name}`}
                      className="grid size-9 shrink-0 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                      data-ocid={`create_image_remove.${index}`}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>

          {listOpportunity.isError ? (
            <p
              className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
              data-ocid="create_error_state"
            >
              Couldn't publish this opportunity. Please check your details and
              try again.
            </p>
          ) : null}

          <div className="flex flex-col gap-2 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-muted-foreground">
              Your listing will appear in the catalog once published.
            </p>
            <Button
              type="submit"
              disabled={!canSubmit || listOpportunity.isPending}
              className="sm:w-auto"
              data-ocid="create_submit_button"
            >
              {listOpportunity.isPending ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Publishing…
                </>
              ) : (
                <>
                  <Megaphone className="size-4" />
                  Publish opportunity
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

export function CreatePage() {
  const { isAuthenticated } = useInternetIdentity();
  const { data: profile, isLoading } = useGetCallerOrganizerProfile();
  const [promptOpen, setPromptOpen] = useState(false);

  return (
    <div
      className="mx-auto max-w-7xl px-5 py-10 md:px-8 md:py-14"
      data-ocid="create_page"
    >
      <header className="mb-8 max-w-2xl">
        <p className="mb-2 text-xs font-semibold tracking-[0.17em] text-accent uppercase">
          MyScout · For organizers
        </p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Create an opportunity.
        </h1>
        <p className="mt-3 text-muted-foreground">
          Share an event or opportunity with students. Add a clear title,
          description, category, and at least one image.
        </p>
      </header>

      {!isAuthenticated ? (
        <Card
          className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
          data-ocid="create_sign_in_state"
        >
          <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
            <Megaphone className="size-7" />
          </span>
          <div className="space-y-1">
            <h2 className="font-display text-xl font-bold text-foreground">
              Sign in to publish
            </h2>
            <p className="text-sm text-muted-foreground">
              You need an organizer account to list opportunities. Sign in to
              get started.
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setPromptOpen(true)}
            className="mt-1"
            data-ocid="create_sign_in_button"
          >
            <Megaphone className="size-4" />
            Sign in to continue
          </Button>
          <SignInPrompt
            open={promptOpen}
            onOpenChange={setPromptOpen}
            title="Sign in to publish"
            description="Create a MyScout account to list opportunities in the catalog."
          />
        </Card>
      ) : isLoading ? (
        <Card className="mx-auto max-w-xl" data-ocid="create_loading_state">
          <CardHeader>
            <CardTitle className="font-display text-xl">
              Checking your organizer account…
            </CardTitle>
          </CardHeader>
        </Card>
      ) : profile ? (
        <CreateForm />
      ) : (
        <Card
          className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
          data-ocid="create_not_organizer_state"
        >
          <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
            <BadgeCheck className="size-7" />
          </span>
          <div className="space-y-1">
            <h2 className="font-display text-xl font-bold text-foreground">
              Register as an organizer first
            </h2>
            <p className="text-sm text-muted-foreground">
              Only verified organizers can publish opportunities. Set up your
              organizer profile to start listing events.
            </p>
          </div>
          <Button
            type="button"
            asChild
            className="mt-1"
            data-ocid="create_register_organizer_button"
          >
            <Link to="/organizer">
              <BadgeCheck className="size-4" />
              Register as an organizer
            </Link>
          </Button>
        </Card>
      )}
    </div>
  );
}
