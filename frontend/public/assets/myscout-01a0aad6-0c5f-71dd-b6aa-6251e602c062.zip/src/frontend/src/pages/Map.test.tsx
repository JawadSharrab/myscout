import App from "@/App";
import type { Opportunity } from "@/backend";
import { createMockActor } from "@/test/mockBackend";
import { resetCoreMock, setAuthState, setMockActor } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

function renderApp(path = "/map") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

describe("Map page", () => {
  beforeEach(() => {
    resetCoreMock();
    setAuthState({ isAuthenticated: false });
  });

  it("renders markers for each opportunity synced with the list", async () => {
    renderApp("/map");

    // The map panel and list render.
    expect(await screen.findByTestId("map_panel")).toBeInTheDocument();
    expect(screen.getByTestId("map_list")).toBeInTheDocument();

    // One marker per opportunity in the catalog.
    await waitFor(() => {
      expect(screen.getAllByTestId(/map_marker\./)).toHaveLength(3);
    });

    // The list shows the same opportunities.
    expect(screen.getByText("Amman Model United Nations")).toBeInTheDocument();
    expect(
      screen.getByText("Makers of Jordan: Future Lab"),
    ).toBeInTheDocument();
    expect(screen.getByText("Winter Community Kitchen")).toBeInTheDocument();
  });

  it("filters markers and list by status", async () => {
    const user = userEvent.setup();
    renderApp("/map");
    await screen.findByTestId("map_panel");
    await waitFor(() => {
      expect(screen.getAllByTestId(/map_marker\./)).toHaveLength(3);
    });

    await user.click(screen.getByTestId("map_status_filter_closed"));

    // Only the closed opportunity remains.
    await waitFor(() => {
      expect(screen.getAllByTestId(/map_marker\./)).toHaveLength(1);
    });
    expect(screen.getByText("Winter Community Kitchen")).toBeInTheDocument();
    expect(
      screen.queryByText("Amman Model United Nations"),
    ).not.toBeInTheDocument();
  });

  it("selecting a marker highlights the matching card and vice versa", async () => {
    const user = userEvent.setup();
    renderApp("/map");
    await screen.findByTestId("map_panel");
    await waitFor(() => {
      expect(screen.getAllByTestId(/map_marker\./)).toHaveLength(3);
    });

    // Click the first marker (Amman Model United Nations).
    const marker = screen.getAllByTestId(/map_marker\./)[0];
    await user.click(marker);

    // The matching card becomes active (aria-pressed on the locate button).
    const locateButtons = screen.getAllByTestId(/map_locate_button\./);
    const activeLocate = locateButtons.find(
      (b) => b.getAttribute("aria-pressed") === "true",
    );
    expect(activeLocate).toBeTruthy();
    expect(activeLocate).toHaveTextContent("Located");
  });

  it("shows an empty state when no opportunities match the filter", async () => {
    // A catalog with no opportunities yields the empty state.
    setMockActor(
      createMockActor({ getCatalog: vi.fn(async () => [] as Opportunity[]) }),
    );
    renderApp("/map");
    await screen.findByTestId("map_panel");

    const emptyState = await screen.findByTestId("map_empty_state");
    expect(emptyState).toBeInTheDocument();
    expect(
      within(emptyState).getByText("Nothing here yet"),
    ).toBeInTheDocument();
    expect(
      within(emptyState).getByText(/No opportunities match this filter/),
    ).toBeInTheDocument();
    expect(
      within(emptyState).getByTestId("map_reset_button"),
    ).toBeInTheDocument();
  });
});
