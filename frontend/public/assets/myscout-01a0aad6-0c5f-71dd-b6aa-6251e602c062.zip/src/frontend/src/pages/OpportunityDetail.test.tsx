import App from "@/App";
import { Category } from "@/backend";
import { mockOpportunities } from "@/test/fixtures";
import { createMockActor } from "@/test/mockBackend";
import { resetCoreMock, setAuthState, setMockActor } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it } from "vitest";

function renderApp(path = "/opportunity/1") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

describe("Opportunity detail page", () => {
  beforeEach(() => {
    resetCoreMock();
    setAuthState({ isAuthenticated: false });
  });

  it("shows full info and the 10-factor weighted rating", async () => {
    renderApp("/opportunity/1");

    expect(
      await screen.findByText("Amman Model United Nations"),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Organized by Amman International Academy"),
    ).toBeInTheDocument();

    // Full info fields.
    expect(screen.getByText("35 JOD")).toBeInTheDocument();
    expect(screen.getByText("2 days")).toBeInTheDocument();
    expect(screen.getByText("Dabouq, Amman")).toBeInTheDocument();
    expect(screen.getByText("15–20")).toBeInTheDocument();

    // 10-factor rating section.
    expect(screen.getByText("Why this score?")).toBeInTheDocument();
    expect(
      screen.getByText("University application value"),
    ).toBeInTheDocument();
    expect(screen.getByText("Skill development")).toBeInTheDocument();
    expect(screen.getByText("Worth your time")).toBeInTheDocument();
    expect(screen.getByText("Recognition / reputation")).toBeInTheDocument();
    expect(screen.getByText("Leadership potential")).toBeInTheDocument();
    expect(screen.getByText("Networking")).toBeInTheDocument();
    expect(screen.getByText("Difficulty / challenge")).toBeInTheDocument();
    expect(screen.getByText("Time commitment")).toBeInTheDocument();
    expect(screen.getByText("Price / value")).toBeInTheDocument();
    expect(screen.getByText("Relevance to interests")).toBeInTheDocument();

    // Overall score is shown.
    expect(screen.getByTestId("overall_score")).toBeInTheDocument();
  });

  it("opens registration and social links in a new tab when present", async () => {
    renderApp("/opportunity/1");

    // The `data-ocid` merges onto the anchor via the Button's asChild slot.
    const register = await screen.findByTestId("registration_link");
    expect(register.tagName).toBe("A");
    expect(register).toHaveAttribute("href", "https://example.com/register");
    expect(register).toHaveAttribute("target", "_blank");

    const social = screen.getByTestId("social_link");
    expect(social.tagName).toBe("A");
    expect(social).toHaveAttribute("href", "https://instagram.com/example");
    expect(social).toHaveAttribute("target", "_blank");
  });

  it("shows links as unavailable when absent", async () => {
    renderApp("/opportunity/2");

    expect(
      await screen.findByTestId("registration_unavailable"),
    ).toBeInTheDocument();
    expect(screen.getByTestId("social_unavailable")).toBeInTheDocument();
  });

  it("labels prototype opportunities as not organizer-verified", async () => {
    // Opportunity 13 is a prototype in the real seed; use a prototype fixture.
    const prototype = { ...mockOpportunities[0], isPrototype: true };
    const { createMockActor } = await import("@/test/mockBackend");
    const { setMockActor } = await import("@/test/mockCore");
    setMockActor(
      createMockActor({
        getOpportunity: async (id) =>
          id === 1n
            ? prototype
            : (mockOpportunities.find((o) => o.id === id) ?? null),
      }),
    );

    renderApp("/opportunity/1");

    expect(
      await screen.findByText("Not organizer-verified"),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/has not been verified by the organizing body/),
    ).toBeInTheDocument();
  });

  it("shows a sign-in prompt when a signed-out user tries to save", async () => {
    const user = userEvent.setup();
    renderApp("/opportunity/1");
    await screen.findByText("Amman Model United Nations");

    const saveButton = screen.getByTestId("save_button");
    await user.click(saveButton);

    const dialog = await screen.findByRole("dialog");
    expect(
      within(dialog).getByRole("heading", { name: "Sign in to save" }),
    ).toBeInTheDocument();
    expect(within(dialog).getByTestId("sign_in_button")).toBeInTheDocument();
  });

  it("persists a save to the account for a signed-in user", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    // Provide interests so the first-sign-in picker does not overlay the page.
    const actor = createMockActor({
      getSavedOpportunities: async () => [],
      getInterests: async () => [Category.academic],
    });
    setMockActor(actor);
    renderApp("/opportunity/1");
    await screen.findByText("Amman Model United Nations");

    await user.click(screen.getByTestId("save_button"));

    await waitFor(() => {
      expect(actor.saveOpportunity).toHaveBeenCalledWith(1n);
    });
  });

  it("unsaves an already-saved opportunity from the detail view", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    const actor = createMockActor({
      getSavedOpportunities: async () => [mockOpportunities[0]],
      getInterests: async () => [Category.academic],
    });
    setMockActor(actor);
    renderApp("/opportunity/1");
    await screen.findByText("Amman Model United Nations");

    // The save button reflects the saved state.
    const saveButton = screen.getByTestId("save_button");
    expect(saveButton).toHaveTextContent("Saved");

    // Clicking it again unsaves from the detail view.
    await user.click(saveButton);

    await waitFor(() => {
      expect(actor.unsaveOpportunity).toHaveBeenCalledWith(1n);
    });
  });
});
