import { HomeTabs } from "@/components/HomeTabs";
import { SaveButton } from "@/components/SaveButton";
import { SignInPrompt } from "@/components/SignInPrompt";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardAction,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAccount } from "@/hooks/useAccount";
import {
  useFilterByInterests,
  useGetCatalog,
  useGetCategories,
  useGetSavedOpportunities,
  useRecommendByInterests,
} from "@/hooks/useQueries";
import { useSaved } from "@/hooks/useSaved";
import { getOverallScore, getScoreColor } from "@/lib/scoring";
import { cn } from "@/lib/utils";
import { type Category, CostFilter, RecommendationMode, Status } from "@/types";
import type { Opportunity } from "@/types";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { Link, useNavigate, useSearch } from "@tanstack/react-router";
import {
  ArrowRight,
  Bookmark,
  CalendarDays,
  Compass,
  MapPin,
  Search,
  SlidersHorizontal,
  Sparkles,
  Ticket,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

const RECOMMENDATION_MODES: Array<{
  value: RecommendationMode;
  label: string;
  hint: string;
}> = [
  {
    value: RecommendationMode.highestRated,
    label: "Highest rated",
    hint: "Best overall scores",
  },
  {
    value: RecommendationMode.closingSoon,
    label: "Closing soon",
    hint: "Deadlines nearest",
  },
  {
    value: RecommendationMode.closest,
    label: "Closest",
    hint: "Nearest to you",
  },
  {
    value: RecommendationMode.university,
    label: "University value",
    hint: "Best for applications",
  },
  {
    value: RecommendationMode.bestValue,
    label: "Best value",
    hint: "Most for your money",
  },
  {
    value: RecommendationMode.skills,
    label: "Skills",
    hint: "Most skill growth",
  },
];

const DISTANCE_OPTIONS = [
  { value: "", label: "Any distance" },
  { value: "5", label: "Within 5 km" },
  { value: "10", label: "Within 10 km" },
  { value: "20", label: "Within 20 km" },
];

function strParam(value: unknown): string {
  return typeof value === "string" ? value : "";
}

function isFree(fee: string): boolean {
  return fee.trim().toLowerCase() === "free";
}

function categoryLabel(cat: Category): string {
  return cat.charAt(0).toUpperCase() + cat.slice(1);
}

function formatDate(timestamp: bigint): string {
  const date = new Date(Number(timestamp / 1_000_000n));
  if (Number.isNaN(date.getTime())) return "Date TBA";
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function matchesSearch(o: Opportunity, q: string): boolean {
  const needle = q.trim().toLowerCase();
  if (!needle) return true;
  return (
    o.name.toLowerCase().includes(needle) ||
    o.organizer.toLowerCase().includes(needle) ||
    o.description.toLowerCase().includes(needle)
  );
}

function matchesFilters(
  o: Opportunity,
  category: string,
  cost: string,
  distance: string,
  status: string,
): boolean {
  if (category && o.category !== category) return false;
  if (cost === CostFilter.free && !isFree(o.fee)) return false;
  if (cost === CostFilter.paid && isFree(o.fee)) return false;
  if (distance && o.distanceKm > Number(distance)) return false;
  if (status && o.status !== status) return false;
  return true;
}

function sortByMode(
  a: Opportunity,
  b: Opportunity,
  mode: RecommendationMode,
): number {
  switch (mode) {
    case RecommendationMode.highestRated:
      return getOverallScore(b) - getOverallScore(a);
    case RecommendationMode.closingSoon:
      return Number(a.deadline) - Number(b.deadline);
    case RecommendationMode.closest:
      return a.distanceKm - b.distanceKm;
    case RecommendationMode.university:
      return (
        Number(b.factorRatings.uniApplicationValue) -
        Number(a.factorRatings.uniApplicationValue)
      );
    case RecommendationMode.bestValue:
      return (
        Number(b.factorRatings.priceValue) - Number(a.factorRatings.priceValue)
      );
    case RecommendationMode.skills:
      return (
        Number(b.factorRatings.skillDevelopment) -
        Number(a.factorRatings.skillDevelopment)
      );
  }
}

function ScoreBadge({ score }: { score: number }) {
  return (
    <span
      className={cn(
        "grid size-11 shrink-0 place-items-center rounded-full border-2 bg-card font-display text-sm font-bold",
        getScoreColor(score),
        score >= 4.5
          ? "border-accent/40"
          : score >= 4.0
            ? "border-primary/30"
            : "border-destructive/30",
      )}
      title={`Overall score ${score.toFixed(1)} / 5`}
      data-ocid="score_badge"
    >
      {score.toFixed(1)}
    </span>
  );
}

function OpportunityCard({ opportunity }: { opportunity: Opportunity }) {
  const score = getOverallScore(opportunity);
  return (
    <Link
      to="/opportunity/$id"
      params={{ id: opportunity.id.toString() }}
      className="group block h-full"
      data-ocid="opportunity_card"
    >
      <Card className="h-full transition-smooth hover:-translate-y-0.5 hover:border-accent/40 hover:shadow-md">
        <CardHeader className="grid-cols-[1fr_auto]">
          <div className="min-w-0">
            <Badge variant="secondary" className="mb-2">
              {categoryLabel(opportunity.category)}
            </Badge>
            <CardTitle className="font-display text-lg leading-snug text-foreground group-hover:text-primary">
              {opportunity.name}
            </CardTitle>
            <p className="mt-1 text-sm font-medium text-muted-foreground">
              {opportunity.organizer}
            </p>
          </div>
          <CardAction>
            <div className="flex items-center gap-2">
              <ScoreBadge score={score} />
              <div
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
                className="inline-flex"
                data-ocid="save_button_wrap"
              >
                <SaveButton id={opportunity.id} name={opportunity.name} />
              </div>
            </div>
          </CardAction>
        </CardHeader>
        <CardContent className="flex flex-1 flex-col gap-4">
          <p className="line-clamp-2 text-sm text-muted-foreground">
            {opportunity.description}
          </p>
          <div className="mt-auto grid grid-cols-2 gap-x-3 gap-y-2 border-t border-border pt-4 text-sm">
            <span className="flex items-center gap-2 text-muted-foreground">
              <CalendarDays className="size-4 text-accent" />
              {formatDate(opportunity.date)}
            </span>
            <span className="flex items-center gap-2 text-muted-foreground">
              <Ticket className="size-4 text-accent" />
              {opportunity.fee}
            </span>
            <span className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="size-4 text-accent" />
              {opportunity.distanceKm.toFixed(1)} km
            </span>
            <span className="flex items-center gap-2 text-muted-foreground">
              <SlidersHorizontal className="size-4 text-accent" />
              {opportunity.status === Status.closingSoon
                ? "Closing soon"
                : opportunity.status === Status.open
                  ? "Open"
                  : "Closed"}
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

function CardSkeleton() {
  return (
    <Card className="h-full">
      <CardHeader className="grid-cols-[1fr_auto]">
        <div className="space-y-2">
          <Skeleton className="h-5 w-24" />
          <Skeleton className="h-5 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
        <CardAction>
          <Skeleton className="size-11 rounded-full" />
        </CardAction>
      </CardHeader>
      <CardContent className="space-y-4">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <div className="grid grid-cols-2 gap-3 border-t border-border pt-4">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-4 w-24" />
        </div>
      </CardContent>
    </Card>
  );
}

function CardGridSkeleton() {
  return (
    <div
      className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
      data-ocid="loading_state"
    >
      {Array.from({ length: 6 }, (_, i) => `skeleton-${i}`).map((id) => (
        <CardSkeleton key={id} />
      ))}
    </div>
  );
}

function ResultsGrid({ results }: { results: Opportunity[] }) {
  return (
    <div
      className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
      data-ocid="opportunity_list"
    >
      {results.map((o) => (
        <OpportunityCard key={o.id.toString()} opportunity={o} />
      ))}
    </div>
  );
}

function FeaturedCard({ opportunity }: { opportunity: Opportunity }) {
  const score = getOverallScore(opportunity);
  const uniValue = Number(opportunity.factorRatings.uniApplicationValue);
  const chips = [
    { label: "Top signal", show: true },
    { label: "Uni value", show: uniValue >= 4 },
    { label: "Closing soon", show: opportunity.status === Status.closingSoon },
    { label: "Closest", show: opportunity.distanceKm <= 5 },
  ].filter((c) => c.show);

  return (
    <Link
      to="/opportunity/$id"
      params={{ id: opportunity.id.toString() }}
      className="group block animate-hero-rise"
      data-ocid="featured_card"
    >
      <div className="relative overflow-hidden rounded-3xl bg-gradient-navy p-6 text-navy-foreground shadow-elevated md:p-8">
        <div className="flex flex-wrap gap-2">
          {chips.map((chip) => (
            <span
              key={chip.label}
              className="rounded-full border border-navy-foreground/25 bg-navy-foreground/10 px-3 py-1 text-xs font-semibold text-navy-foreground"
              data-ocid={`featured_chip.${chip.label.toLowerCase().replace(/\s+/g, "_")}`}
            >
              {chip.label}
            </span>
          ))}
        </div>
        <p className="mt-6 text-xs font-semibold tracking-[0.16em] text-navy-foreground/70 uppercase">
          Featured pick
        </p>
        <h3 className="mt-2 font-display text-2xl font-bold leading-snug text-navy-foreground md:text-3xl">
          {opportunity.name}
        </h3>
        <p className="mt-3 text-sm text-navy-foreground/80">
          {score.toFixed(1)} / 5 · {uniValue.toFixed(1)} university application
          value · {opportunity.distanceKm.toFixed(1)} km away
        </p>
        <span className="mt-6 inline-flex items-center gap-2 rounded-full bg-navy-foreground px-5 py-2.5 text-sm font-semibold text-navy transition-colors group-hover:bg-white">
          Explore the pick
          <ArrowRight className="size-4" />
        </span>
      </div>
    </Link>
  );
}

function FeaturedSkeleton() {
  return (
    <div
      className="animate-pulse rounded-3xl bg-gradient-navy p-6 md:p-8"
      data-ocid="featured_loading_state"
    >
      <div className="flex flex-wrap gap-2">
        <Skeleton className="h-6 w-20 rounded-full bg-navy-foreground/20" />
        <Skeleton className="h-6 w-16 rounded-full bg-navy-foreground/20" />
      </div>
      <Skeleton className="mt-6 h-4 w-24 bg-navy-foreground/20" />
      <Skeleton className="mt-3 h-8 w-3/4 bg-navy-foreground/20" />
      <Skeleton className="mt-3 h-4 w-2/3 bg-navy-foreground/20" />
      <Skeleton className="mt-6 h-10 w-40 rounded-full bg-navy-foreground/20" />
    </div>
  );
}

function ForYouTab() {
  const { isAuthenticated } = useInternetIdentity();
  const { interests, interestsLoading, openInterestsPicker } = useAccount();
  const { data: recommended = [], isLoading: recommendedLoading } =
    useRecommendByInterests();
  const { data: filtered = [], isLoading: filteredLoading } =
    useFilterByInterests();
  const [view, setView] = useState<"recommended" | "filtered">("recommended");
  const [promptOpen, setPromptOpen] = useState(false);

  if (!isAuthenticated) {
    return (
      <Card
        className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
        data-ocid="for_you_sign_in_state"
      >
        <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
          <Sparkles className="size-7" />
        </span>
        <div className="space-y-1">
          <h2 className="font-display text-xl font-bold text-foreground">
            Sign in for personalized picks
          </h2>
          <p className="text-sm text-muted-foreground">
            Tell us what you're into and we'll surface the opportunities across
            Amman that actually fit you.
          </p>
        </div>
        <Button
          type="button"
          onClick={() => setPromptOpen(true)}
          className="mt-1"
          data-ocid="for_you_sign_in_button"
        >
          <Sparkles className="size-4" />
          Sign in to personalize
        </Button>
        <SignInPrompt
          open={promptOpen}
          onOpenChange={setPromptOpen}
          title="Sign in to personalize"
          description="Create a MyScout account to get recommendations matched to your interests."
        />
      </Card>
    );
  }

  if (interestsLoading) {
    return <CardGridSkeleton />;
  }

  if (interests.length === 0) {
    return (
      <Card
        className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
        data-ocid="for_you_no_interests_state"
      >
        <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
          <Sparkles className="size-7" />
        </span>
        <div className="space-y-1">
          <h2 className="font-display text-xl font-bold text-foreground">
            Pick your interests
          </h2>
          <p className="text-sm text-muted-foreground">
            Choose a few categories and we'll re-rank and surface the
            opportunities that match what you care about.
          </p>
        </div>
        <Button
          type="button"
          onClick={openInterestsPicker}
          className="mt-1"
          data-ocid="for_you_choose_interests_button"
        >
          <Sparkles className="size-4" />
          Choose interests
        </Button>
      </Card>
    );
  }

  const loading = view === "recommended" ? recommendedLoading : filteredLoading;
  const results = view === "recommended" ? recommended : filtered;

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-foreground">
            For you
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {view === "recommended"
              ? "Re-ranked to match your interests."
              : "Only opportunities matching your interests."}
          </p>
        </div>
        <div className="flex gap-1.5" data-ocid="for_you_view_toggle">
          <button
            type="button"
            onClick={() => setView("recommended")}
            className={cn(
              "rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors",
              view === "recommended"
                ? "bg-accent text-accent-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground",
            )}
            data-ocid="for_you_view.recommended"
          >
            Recommended
          </button>
          <button
            type="button"
            onClick={() => setView("filtered")}
            className={cn(
              "rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors",
              view === "filtered"
                ? "bg-accent text-accent-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground",
            )}
            data-ocid="for_you_view.filtered"
          >
            Only matching
          </button>
        </div>
      </div>

      {loading ? (
        <CardGridSkeleton />
      ) : results.length === 0 ? (
        <div
          className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card/50 px-6 py-20 text-center"
          data-ocid="for_you_empty_state"
        >
          <span className="grid size-14 place-items-center rounded-2xl bg-muted text-muted-foreground">
            <Sparkles className="size-7" />
          </span>
          <h3 className="mt-5 font-display text-xl font-bold text-foreground">
            Nothing matches your interests yet
          </h3>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            Try the Explore tab to browse the full catalog, or adjust your
            interests from your account menu.
          </p>
          <Button
            type="button"
            onClick={openInterestsPicker}
            className="mt-6 rounded-full"
            data-ocid="for_you_empty_edit_interests_button"
          >
            Edit interests
          </Button>
        </div>
      ) : (
        <ResultsGrid results={results} />
      )}
    </div>
  );
}

function SavedTab() {
  const { isAuthenticated } = useSaved();
  const { data: savedOpportunities = [], isLoading } =
    useGetSavedOpportunities();
  const [promptOpen, setPromptOpen] = useState(false);

  if (!isAuthenticated) {
    return (
      <Card
        className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
        data-ocid="saved_tab_sign_in_state"
      >
        <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
          <Bookmark className="size-7" />
        </span>
        <div className="space-y-1">
          <h2 className="font-display text-xl font-bold text-foreground">
            Sign in to see your shortlist
          </h2>
          <p className="text-sm text-muted-foreground">
            Your saved opportunities live with your account. Sign in to keep
            your shortlist across visits.
          </p>
        </div>
        <Button
          type="button"
          onClick={() => setPromptOpen(true)}
          className="mt-1"
          data-ocid="saved_tab_sign_in_button"
        >
          <Bookmark className="size-4" />
          Sign in to save
        </Button>
        <SignInPrompt
          open={promptOpen}
          onOpenChange={setPromptOpen}
          title="Sign in to save"
          description="Create a MyScout account to keep your shortlist across visits and come back to it later."
        />
      </Card>
    );
  }

  if (isLoading) {
    return <CardGridSkeleton />;
  }

  if (savedOpportunities.length === 0) {
    return (
      <Card
        className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
        data-ocid="saved_tab_empty_state"
      >
        <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
          <Sparkles className="size-7" />
        </span>
        <div className="space-y-1">
          <h2 className="font-display text-xl font-bold text-foreground">
            Nothing saved yet
          </h2>
          <p className="text-sm text-muted-foreground">
            Tap the bookmark on any opportunity to add it to your shortlist.
            Your saved picks will show up here.
          </p>
        </div>
        <Button
          type="button"
          asChild
          className="mt-1"
          data-ocid="saved_tab_browse_button"
        >
          <Link to="/" search={(prev) => ({ ...prev, tab: "explore" })}>
            <Compass className="size-4" />
            Discover opportunities
          </Link>
        </Button>
      </Card>
    );
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-foreground">
            Saved
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {savedOpportunities.length}{" "}
            {savedOpportunities.length === 1 ? "opportunity" : "opportunities"}{" "}
            saved to your shortlist.
          </p>
        </div>
      </div>
      <ResultsGrid results={savedOpportunities} />
    </div>
  );
}

function ExploreTab() {
  const search = useSearch({ from: "/" });
  const navigate = useNavigate({ from: "/" });

  const params = search as Record<string, unknown>;
  const q = strParam(params.q);
  const category = strParam(params.category);
  const cost = strParam(params.cost);
  const distance = strParam(params.distance);
  const status = strParam(params.status);
  const mode = strParam(params.mode);

  const [query, setQuery] = useState(q);

  const { data: catalog = [], isLoading } = useGetCatalog();
  const { data: categories = [] } = useGetCategories();

  const activeMode = RECOMMENDATION_MODES.some((m) => m.value === mode)
    ? (mode as RecommendationMode)
    : RecommendationMode.highestRated;

  const updateSearch = (patch: Record<string, unknown>) => {
    void navigate({ search: (prev) => ({ ...prev, ...patch }) });
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      void navigate({
        search: (prev) => ({ ...prev, q: query.trim() ? query : undefined }),
      });
    }, 300);
    return () => clearTimeout(timer);
  }, [query, navigate]);

  const results = useMemo(() => {
    const filtered = catalog.filter(
      (o) =>
        matchesSearch(o, q) &&
        matchesFilters(o, category, cost, distance, status),
    );
    return [...filtered].sort((a, b) => sortByMode(a, b, activeMode));
  }, [catalog, q, category, cost, distance, status, activeMode]);

  const hasActiveFilters =
    Boolean(category) || Boolean(cost) || Boolean(distance) || Boolean(status);

  const clearAll = () => {
    setQuery("");
    const patch: Record<string, unknown> = {
      q: undefined,
      category: undefined,
      cost: undefined,
      distance: undefined,
      status: undefined,
      mode: undefined,
    };
    void navigate({ search: (prev) => ({ ...prev, ...patch }) });
  };

  const activeModeLabel =
    RECOMMENDATION_MODES.find((m) => m.value === activeMode)?.label ??
    "Highest rated";

  return (
    <div>
      {/* Search */}
      <div className="flex max-w-xl items-center gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm">
        <Search className="ml-2 size-5 shrink-0 text-muted-foreground" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search opportunities, organizers, or keywords…"
          aria-label="Search opportunities"
          className="h-10 w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
          data-ocid="search_input"
        />
        {query ? (
          <button
            type="button"
            onClick={() => setQuery("")}
            aria-label="Clear search"
            className="grid size-8 shrink-0 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            data-ocid="clear_search_button"
          >
            <X className="size-4" />
          </button>
        ) : null}
      </div>

      {/* Category pills */}
      <fieldset
        className="mt-5 flex flex-wrap gap-2 border-0 p-0"
        aria-label="Filter by category"
        data-ocid="category_filter"
      >
        <button
          type="button"
          onClick={() => updateSearch({ category: undefined })}
          className={cn(
            "rounded-full border px-4 py-2 text-sm font-semibold transition-colors",
            !category
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground",
          )}
          data-ocid="category_pill.all"
        >
          All
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() =>
              updateSearch({ category: category === cat ? undefined : cat })
            }
            className={cn(
              "rounded-full border px-4 py-2 text-sm font-semibold transition-colors",
              category === cat
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground",
            )}
            data-ocid={`category_pill.${cat}`}
          >
            {categoryLabel(cat)}
          </button>
        ))}
      </fieldset>

      {/* Filter + sort bar */}
      <div className="mt-6 rounded-2xl border border-border bg-card/60 p-4">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Cost
            </span>
            <fieldset
              className="flex gap-1.5 border-0 p-0"
              aria-label="Filter by cost"
            >
              <button
                type="button"
                onClick={() => updateSearch({ cost: undefined })}
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  !cost
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="cost_pill.any"
              >
                Any
              </button>
              <button
                type="button"
                onClick={() =>
                  updateSearch({
                    cost:
                      cost === CostFilter.free ? undefined : CostFilter.free,
                  })
                }
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  cost === CostFilter.free
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="cost_pill.free"
              >
                Free
              </button>
              <button
                type="button"
                onClick={() =>
                  updateSearch({
                    cost:
                      cost === CostFilter.paid ? undefined : CostFilter.paid,
                  })
                }
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  cost === CostFilter.paid
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="cost_pill.paid"
              >
                Paid
              </button>
            </fieldset>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Distance
            </span>
            <fieldset
              className="flex gap-1.5 border-0 p-0"
              aria-label="Filter by distance"
            >
              {DISTANCE_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    updateSearch({ distance: opt.value || undefined })
                  }
                  className={cn(
                    "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                    distance === opt.value
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:text-foreground",
                  )}
                  data-ocid={`distance_pill.${opt.value || "any"}`}
                >
                  {opt.label}
                </button>
              ))}
            </fieldset>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Status
            </span>
            <fieldset
              className="flex gap-1.5 border-0 p-0"
              aria-label="Filter by status"
            >
              <button
                type="button"
                onClick={() => updateSearch({ status: undefined })}
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  !status
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="status_pill.any"
              >
                Any
              </button>
              <button
                type="button"
                onClick={() =>
                  updateSearch({
                    status: status === Status.open ? undefined : Status.open,
                  })
                }
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  status === Status.open
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="status_pill.open"
              >
                Open
              </button>
              <button
                type="button"
                onClick={() =>
                  updateSearch({
                    status:
                      status === Status.closingSoon
                        ? undefined
                        : Status.closingSoon,
                  })
                }
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  status === Status.closingSoon
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="status_pill.closing_soon"
              >
                Closing soon
              </button>
              <button
                type="button"
                onClick={() =>
                  updateSearch({
                    status:
                      status === Status.closed ? undefined : Status.closed,
                  })
                }
                className={cn(
                  "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                  status === Status.closed
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground",
                )}
                data-ocid="status_pill.closed"
              >
                Closed
              </button>
            </fieldset>
          </div>
        </div>

        {/* Recommendation mode selector */}
        <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-3">
          <span className="mr-1 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
            Sort by
          </span>
          {RECOMMENDATION_MODES.map((m) => (
            <button
              key={m.value}
              type="button"
              onClick={() =>
                updateSearch({
                  mode: activeMode === m.value ? undefined : m.value,
                })
              }
              title={m.hint}
              className={cn(
                "rounded-full border px-3.5 py-1.5 text-sm font-semibold transition-colors",
                activeMode === m.value
                  ? "border-accent bg-accent text-accent-foreground"
                  : "border-border bg-card text-muted-foreground hover:border-accent/40 hover:text-foreground",
              )}
              data-ocid={`mode.${m.value}`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="mt-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-xl font-bold text-foreground">
              {isLoading
                ? "Loading opportunities…"
                : `${results.length} opportunities`}
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {isLoading
                ? "Fetching the latest from Amman's hills."
                : `Sorted by ${activeModeLabel.toLowerCase()}.`}
            </p>
          </div>
          {hasActiveFilters || q ? (
            <button
              type="button"
              onClick={clearAll}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3.5 py-1.5 text-sm font-semibold text-muted-foreground transition-colors hover:border-destructive/40 hover:text-destructive"
              data-ocid="clear_filters_button"
            >
              <X className="size-4" />
              Clear filters
            </button>
          ) : null}
        </div>

        {isLoading ? (
          <CardGridSkeleton />
        ) : results.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card/50 px-6 py-20 text-center"
            data-ocid="empty_state"
          >
            <span className="grid size-14 place-items-center rounded-2xl bg-muted text-muted-foreground">
              <Search className="size-7" />
            </span>
            <h3 className="mt-5 font-display text-xl font-bold text-foreground">
              Nothing matches those filters
            </h3>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              Try widening your distance, removing a category, or clearing the
              search to see more opportunities across Amman.
            </p>
            <button
              type="button"
              onClick={clearAll}
              className="mt-6 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
              data-ocid="empty_state_clear_button"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <ResultsGrid results={results} />
        )}
      </div>
    </div>
  );
}

export function DiscoverPage() {
  const { data: catalog = [], isLoading } = useGetCatalog();
  const search = useSearch({ from: "/" });
  const navigate = useNavigate({ from: "/" });

  const params = search as Record<string, unknown>;
  const tabParam = strParam(params.tab);
  const initialTab =
    tabParam === "explore" || tabParam === "saved" ? tabParam : "forYou";
  const [activeTab, setActiveTab] = useState(initialTab);

  useEffect(() => {
    setActiveTab(
      tabParam === "explore" || tabParam === "saved" ? tabParam : "forYou",
    );
  }, [tabParam]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    void navigate({
      search: (prev) => ({ ...prev, tab: value }),
    });
  };

  const featured = useMemo(() => {
    if (!catalog.length) return undefined;
    return [...catalog].sort(
      (a, b) => getOverallScore(b) - getOverallScore(a),
    )[0];
  }, [catalog]);

  return (
    <div className="bg-background">
      {/* Hero */}
      <section className="border-b border-border bg-gradient-subtle">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 py-12 md:px-8 md:py-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div className="animate-hero-rise">
            <p className="mb-3 inline-flex items-center gap-2 text-xs font-semibold tracking-[0.18em] text-accent uppercase">
              <Compass className="size-4" />
              MyScout · Amman
            </p>
            <h1 className="max-w-2xl font-display text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl">
              Find something{" "}
              <span className="text-gradient-sky">worth doing.</span>
            </h1>
            <p className="mt-4 max-w-xl text-base text-muted-foreground md:text-lg">
              Discover extracurricular opportunities across Amman's hills that
              actually fit you — browse, filter, and compare by what matters.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Button
                type="button"
                onClick={() => setActiveTab("explore")}
                className="rounded-full px-6 py-2.5"
                data-ocid="hero_explore_button"
              >
                Explore opportunities
                <ArrowRight className="size-4" />
              </Button>
            </div>
          </div>

          {isLoading ? (
            <FeaturedSkeleton />
          ) : featured ? (
            <FeaturedCard opportunity={featured} />
          ) : null}
        </div>
      </section>

      {/* Tabbed content */}
      <section className="mx-auto max-w-7xl px-5 py-8 md:px-8 md:py-10">
        <HomeTabs
          value={activeTab}
          onValueChange={handleTabChange}
          forYou={<ForYouTab />}
          explore={<ExploreTab />}
          saved={<SavedTab />}
        />
      </section>
    </div>
  );
}
