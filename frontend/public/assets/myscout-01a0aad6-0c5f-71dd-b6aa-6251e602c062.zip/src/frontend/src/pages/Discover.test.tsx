import App from "@/App";
import { Category, Status } from "@/backend";
import { mockOpportunities } from "@/test/fixtures";
import { createMockActor } from "@/test/mockBackend";
import { resetCoreMock, setAuthState, setMockActor } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

/** Signed-in users with interests set avoid the first-sign-in picker overlay. */
function signedInActor(overrides: Parameters<typeof createMockActor>[0] = {}) {
  return createMockActor({
    getInterests: async () => [Category.academic],
    ...overrides,
  });
}

function renderApp(path = "/") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

/** The homepage now defaults to the "For you" tab; the catalog lives in Explore. */
async function openExplore(user: ReturnType<typeof userEvent.setup>) {
  await user.click(await screen.findByTestId("home_tab.explore"));
  await screen.findByTestId("opportunity_list");
}

/** The featured hero card and the Explore list both show the top-rated pick. */
function list() {
  return within(screen.getByTestId("opportunity_list"));
}

describe("Discover page", () => {
  beforeEach(() => {
    resetCoreMock();
    setAuthState({ isAuthenticated: false });
  });

  it("renders the seeded catalog as clickable opportunity cards", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    expect(list().getByText("Amman Model United Nations")).toBeInTheDocument();
    expect(
      list().getByText("Makers of Jordan: Future Lab"),
    ).toBeInTheDocument();
    expect(list().getByText("Winter Community Kitchen")).toBeInTheDocument();

    // Cards show organizer, category, fee, distance, and status.
    expect(list().getByText("Amman International Academy")).toBeInTheDocument();
    expect(list().getByText("35 JOD")).toBeInTheDocument();
    expect(list().getByText("7.4 km")).toBeInTheDocument();
    expect(list().getAllByText("Academic").length).toBeGreaterThan(0);

    // Cards are links to the detail page.
    const card = list().getByText("Amman Model United Nations").closest("a");
    expect(card).toHaveAttribute("href", "/opportunity/1");
  });

  it("filters by category via the category pills", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    await user.click(screen.getByTestId("category_pill.volunteering"));

    expect(
      list().queryByText("Amman Model United Nations"),
    ).not.toBeInTheDocument();
    expect(list().getByText("Winter Community Kitchen")).toBeInTheDocument();
  });

  it("filters by cost (free/paid)", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    await user.click(screen.getByTestId("cost_pill.free"));

    expect(
      list().queryByText("Amman Model United Nations"),
    ).not.toBeInTheDocument();
    expect(
      list().getByText("Makers of Jordan: Future Lab"),
    ).toBeInTheDocument();
    expect(list().getByText("Winter Community Kitchen")).toBeInTheDocument();
  });

  it("filters by status (open/closing-soon/closed)", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    await user.click(screen.getByTestId("status_pill.closed"));

    expect(
      list().queryByText("Amman Model United Nations"),
    ).not.toBeInTheDocument();
    expect(list().getByText("Winter Community Kitchen")).toBeInTheDocument();
  });

  it("filters by distance", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    await user.click(screen.getByTestId("distance_pill.5"));

    // No opportunities are within 5 km, so the empty state replaces the list.
    expect(
      await screen.findByText("Nothing matches those filters"),
    ).toBeInTheDocument();
  });

  it("searches by keyword across name, organizer, and description", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    const search = screen.getByLabelText("Search opportunities");
    await user.type(search, "Tkiyet");

    // The search is debounced (300ms) and applied via the URL, so wait for the
    // non-matching card to disappear.
    await waitFor(() => {
      expect(
        list().queryByText("Amman Model United Nations"),
      ).not.toBeInTheDocument();
    });
    expect(list().getByText("Winter Community Kitchen")).toBeInTheDocument();
  });

  it("shows an empty state when no opportunities match the filters", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    // Filter to a category with no matching opportunities.
    await user.click(screen.getByTestId("category_pill.volunteering"));
    await user.click(screen.getByTestId("status_pill.open"));

    expect(
      await screen.findByText("Nothing matches those filters"),
    ).toBeInTheDocument();
  });

  it("reorders by recommendation mode with a clear active indicator", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    // Default mode is highest-rated; MUN (4.3) should sort before Makers (4.2).
    const list = screen.getByTestId("opportunity_list");
    const names = within(list).getAllByText(
      /Amman Model United Nations|Makers of Jordan/,
    );
    expect(names[0]).toHaveTextContent("Amman Model United Nations");

    // Switch to "Closest" mode.
    await user.click(screen.getByTestId("mode.closest"));

    // Makers (5.1 km) should now sort before MUN (7.4 km).
    const list2 = screen.getByTestId("opportunity_list");
    const names2 = within(list2).getAllByText(
      /Amman Model United Nations|Makers of Jordan/,
    );
    expect(names2[0]).toHaveTextContent("Makers of Jordan");
  });

  it("survives refresh and is shareable through the URL", async () => {
    const user = userEvent.setup();
    renderApp("/");
    await openExplore(user);

    await user.click(screen.getByTestId("status_pill.closed"));

    // The URL reflects the active filter.
    await waitFor(() => {
      expect(window.location.search).toContain("status=closed");
    });

    // Re-render from the same URL (simulating a refresh) keeps the filter.
    const { unmount } = renderApp("/?status=closed&tab=explore");
    await screen.findByTestId("opportunity_list");
    expect(
      list().queryByText("Amman Model United Nations"),
    ).not.toBeInTheDocument();
    unmount();
  });

  it("renders the restored hero: serif headline, navy featured card, and pill chips", async () => {
    renderApp("/");

    // Bold serif headline.
    const headline = await screen.findByRole("heading", { level: 1 });
    expect(headline.textContent).toContain("Find something worth doing.");

    // Navy featured card with the "Explore the pick" CTA.
    const featured = await screen.findByTestId("featured_card");
    expect(within(featured).getByText("Explore the pick")).toBeInTheDocument();
    expect(within(featured).getByText("Featured pick")).toBeInTheDocument();

    // Pill chips on the featured card.
    expect(
      within(featured).getByTestId("featured_chip.top_signal"),
    ).toBeInTheDocument();
  });

  it("uses a tabbed layout (For you / Explore / Saved) instead of one long scroll", async () => {
    const user = userEvent.setup();
    renderApp("/");

    // The three homepage tabs are present.
    expect(await screen.findByTestId("home_tab.for_you")).toBeInTheDocument();
    expect(screen.getByTestId("home_tab.explore")).toBeInTheDocument();
    expect(screen.getByTestId("home_tab.saved")).toBeInTheDocument();

    // The homepage defaults to the "For you" tab.
    expect(
      await screen.findByText("Sign in for personalized picks"),
    ).toBeInTheDocument();

    // Switching to the Saved tab shows the saved shortlist state.
    await user.click(screen.getByTestId("home_tab.saved"));
    expect(
      await screen.findByText("Sign in to see your shortlist"),
    ).toBeInTheDocument();
  });

  it("switches from the Saved tab to Explore via its empty-state button", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    // Signed-in user with nothing saved -> the Saved tab shows its empty state.
    setMockActor(
      signedInActor({
        getSavedOpportunities: async () => [],
      }),
    );
    renderApp("/");

    // Open the Saved tab.
    await user.click(await screen.findByTestId("home_tab.saved"));
    expect(await screen.findByText("Nothing saved yet")).toBeInTheDocument();

    // The "Discover opportunities" button navigates to ?tab=explore. Because
    // we are already on "/", the tab param change must re-sync the active tab
    // (the useEffect) so the Explore catalog actually appears.
    await user.click(screen.getByTestId("saved_tab_browse_button"));

    expect(await screen.findByTestId("opportunity_list")).toBeInTheDocument();
    expect(list().getByText("Amman Model United Nations")).toBeInTheDocument();
  });

  it("shows the first-sign-in interests picker with a working Skip", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    // No interests set -> the onboarding picker opens on first sign-in.
    setMockActor(
      createMockActor({
        getInterests: async () => [],
      }),
    );
    renderApp("/");

    // The onboarding picker appears with multi-select options and a Skip.
    const dialog = await screen.findByRole("dialog");
    expect(
      within(dialog).getByRole("heading", { name: "What are you into?" }),
    ).toBeInTheDocument();
    expect(
      within(dialog).getByTestId("interest_option.academic"),
    ).toBeInTheDocument();
    expect(
      within(dialog).getByTestId("interest_option.volunteering"),
    ).toBeInTheDocument();

    // Skipping proceeds to the homepage without personalization.
    await user.click(within(dialog).getByTestId("interests_skip_button"));
    await waitFor(() => {
      expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    });
    // The homepage is still reachable after skipping.
    expect(await screen.findByRole("heading", { level: 1 })).toHaveTextContent(
      "Find something worth doing.",
    );
  });

  it("re-ranks the For you tab from the caller's interests", async () => {
    setAuthState({ isAuthenticated: true });
    setMockActor(
      signedInActor({
        recommendByInterests: async () => [mockOpportunities[0]],
      }),
    );
    renderApp("/");

    // The For you tab surfaces the interest-matched recommendation.
    expect(
      await screen.findByText("Amman Model United Nations"),
    ).toBeInTheDocument();
    expect(
      screen.getByText("Re-ranked to match your interests."),
    ).toBeInTheDocument();
  });

  it("editing interests re-ranks the For you tab", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    const actor = signedInActor({
      recommendByInterests: vi.fn(async () => []),
    });
    setMockActor(actor);
    renderApp("/");

    // With no recommendations, the For you tab shows its empty state, whose
    // "Edit interests" button opens the picker directly (no dropdown menu).
    await user.click(
      await screen.findByTestId("for_you_empty_edit_interests_button"),
    );
    const dialog = await screen.findByRole("dialog");
    await user.click(
      within(dialog).getByTestId("interest_option.volunteering"),
    );
    await user.click(within(dialog).getByTestId("interests_save_button"));

    // Saving persists the new interests.
    await waitFor(() => {
      expect(actor.setInterests).toHaveBeenCalledWith([
        Category.academic,
        Category.volunteering,
      ]);
    });

    // The homepage re-ranks: the recommendation query is invalidated and
    // re-fetched with the updated interests.
    await waitFor(() => {
      expect(actor.recommendByInterests).toHaveBeenCalledTimes(2);
    });
  });
});
