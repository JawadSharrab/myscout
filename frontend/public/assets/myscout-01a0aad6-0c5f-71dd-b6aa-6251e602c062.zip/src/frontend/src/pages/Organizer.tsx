import { SignInPrompt } from "@/components/SignInPrompt";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useCreateOrganizerAccount,
  useGetCallerOrganizerProfile,
} from "@/hooks/useQueries";
import { useInternetIdentity } from "@caffeineai/core-infrastructure";
import { Link } from "@tanstack/react-router";
import { BadgeCheck, Building2, Mail, Megaphone } from "lucide-react";
import { type FormEvent, useState } from "react";

function OrganizerSkeleton() {
  return (
    <Card className="mx-auto max-w-xl" data-ocid="organizer_loading_state">
      <CardHeader>
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-4 w-72" />
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-9 w-full" />
      </CardContent>
    </Card>
  );
}

function OrganizerForm() {
  const createOrganizer = useCreateOrganizerAccount();
  const [name, setName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [organization, setOrganization] = useState("");

  const canSubmit =
    name.trim().length > 0 &&
    contactEmail.trim().length > 0 &&
    organization.trim().length > 0;

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (!canSubmit) return;
    createOrganizer.mutate({
      name: name.trim(),
      contactEmail: contactEmail.trim(),
      organization: organization.trim(),
    });
  };

  return (
    <Card className="mx-auto max-w-xl" data-ocid="organizer_form">
      <CardHeader>
        <CardTitle className="font-display text-xl">
          Create your organizer profile
        </CardTitle>
        <CardDescription>
          This name, email, and organization appear on every opportunity you
          publish to the catalog.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          <div className="flex flex-col gap-2">
            <Label htmlFor="organizer-name">Your name</Label>
            <Input
              id="organizer-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Amira Hassan"
              autoComplete="name"
              data-ocid="organizer_name_input"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="organizer-email">Contact email</Label>
            <Input
              id="organizer-email"
              type="email"
              value={contactEmail}
              onChange={(event) => setContactEmail(event.target.value)}
              placeholder="you@organization.org"
              autoComplete="email"
              data-ocid="organizer_email_input"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="organizer-org">Organization</Label>
            <Input
              id="organizer-org"
              value={organization}
              onChange={(event) => setOrganization(event.target.value)}
              placeholder="e.g. Amman Youth Hub"
              autoComplete="organization"
              data-ocid="organizer_org_input"
            />
          </div>

          {createOrganizer.isError ? (
            <p
              className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
              data-ocid="organizer_error_state"
            >
              Couldn't create your organizer account. Please try again.
            </p>
          ) : null}

          <Button
            type="submit"
            disabled={!canSubmit || createOrganizer.isPending}
            className="w-full"
            data-ocid="organizer_submit_button"
          >
            {createOrganizer.isPending
              ? "Creating…"
              : "Create organizer account"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function OrganizerProfileCard({
  profile,
}: {
  profile: { name: string; contactEmail: string; organization: string };
}) {
  return (
    <Card className="mx-auto max-w-xl" data-ocid="organizer_profile_state">
      <CardHeader>
        <div className="flex items-center gap-3">
          <span className="grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary">
            <BadgeCheck className="size-6" />
          </span>
          <div>
            <CardTitle className="font-display text-xl">
              {profile.name}
            </CardTitle>
            <CardDescription className="flex items-center gap-1.5">
              <Building2 className="size-3.5" />
              {profile.organization}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/40 px-4 py-3">
          <Mail className="size-4 shrink-0 text-accent" />
          <div className="min-w-0">
            <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              Contact email
            </p>
            <p className="truncate text-sm font-medium text-foreground">
              {profile.contactEmail}
            </p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          You're all set to publish opportunities. Head to the create page to
          list your first event.
        </p>
        <Button
          type="button"
          asChild
          className="w-full"
          data-ocid="organizer_create_link"
        >
          <Link to="/create">
            <Megaphone className="size-4" />
            Create an opportunity
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}

export function OrganizerPage() {
  const { isAuthenticated } = useInternetIdentity();
  const { data: profile, isLoading } = useGetCallerOrganizerProfile();
  const [promptOpen, setPromptOpen] = useState(false);

  return (
    <div
      className="mx-auto max-w-7xl px-5 py-10 md:px-8 md:py-14"
      data-ocid="organizer_page"
    >
      <header className="mb-8 max-w-2xl">
        <p className="mb-2 text-xs font-semibold tracking-[0.17em] text-accent uppercase">
          MyScout · For organizers
        </p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Organizer account.
        </h1>
        <p className="mt-3 text-muted-foreground">
          Set up your organizer profile so students can see who's behind each
          opportunity you publish.
        </p>
      </header>

      {!isAuthenticated ? (
        <Card
          className="mx-auto max-w-xl items-center gap-4 px-8 py-12 text-center"
          data-ocid="organizer_sign_in_state"
        >
          <span className="grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
            <Megaphone className="size-7" />
          </span>
          <div className="space-y-1">
            <h2 className="font-display text-xl font-bold text-foreground">
              Sign in to become an organizer
            </h2>
            <p className="text-sm text-muted-foreground">
              Your organizer account lives with your MyScout identity. Sign in
              to create one and start listing opportunities.
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setPromptOpen(true)}
            className="mt-1"
            data-ocid="organizer_sign_in_button"
          >
            <Megaphone className="size-4" />
            Sign in to continue
          </Button>
          <SignInPrompt
            open={promptOpen}
            onOpenChange={setPromptOpen}
            title="Sign in to become an organizer"
            description="Create a MyScout account to set up your organizer profile and publish opportunities."
          />
        </Card>
      ) : isLoading ? (
        <OrganizerSkeleton />
      ) : profile ? (
        <OrganizerProfileCard profile={profile} />
      ) : (
        <OrganizerForm />
      )}
    </div>
  );
}
