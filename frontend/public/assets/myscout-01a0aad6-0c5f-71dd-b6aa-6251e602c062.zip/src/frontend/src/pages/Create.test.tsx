import App from "@/App";
import { Category } from "@/backend";
import { createMockActor } from "@/test/mockBackend";
import { resetCoreMock, setAuthState, setMockActor } from "@/test/mockCore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it } from "vitest";

function renderApp(path = "/create") {
  window.history.pushState({}, "", path);
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  return render(
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>,
  );
}

/** Signed-in users with interests set avoid the first-sign-in picker overlay. */
function signedInActor(overrides: Parameters<typeof createMockActor>[0] = {}) {
  return createMockActor({
    getInterests: async () => [Category.academic],
    ...overrides,
  });
}

describe("Create page", () => {
  beforeEach(() => {
    resetCoreMock();
  });

  it("prompts signed-out users to sign in before publishing", async () => {
    setAuthState({ isAuthenticated: false });
    renderApp("/create");

    expect(await screen.findByText("Sign in to publish")).toBeInTheDocument();
    expect(screen.getByTestId("create_sign_in_button")).toBeInTheDocument();
    expect(screen.queryByTestId("create_form")).not.toBeInTheDocument();
  });

  it("requires at least one uploaded image before publishing", async () => {
    const user = userEvent.setup();
    setAuthState({ isAuthenticated: true });
    // The listing form is gated on an organizer profile, so provide one.
    setMockActor(
      signedInActor({
        getCallerOrganizerProfile: async () => ({
          name: "Amira Hassan",
          contactEmail: "amira@example.org",
          organization: "Amman Youth Hub",
        }),
      }),
    );
    renderApp("/create");

    // The listing form is shown for signed-in organizers.
    expect(await screen.findByTestId("create_form")).toBeInTheDocument();

    // Fill in the required text fields.
    await user.type(
      screen.getByTestId("create_name_input"),
      "Amman Design Hackathon 2026",
    );
    await user.type(
      screen.getByTestId("create_description_input"),
      "A weekend of prototyping for students.",
    );

    // The submit button is disabled until an image is added.
    const submit = screen.getByTestId("create_submit_button");
    expect(submit).toBeDisabled();

    // Upload an image (the ExternalBlob is mocked in test setup).
    const file = new File(["fake-image-bytes"], "poster.png", {
      type: "image/png",
    });
    await user.upload(screen.getByTestId("create_file_input"), file);
    expect(
      await screen.findByTestId("create_image_item.0"),
    ).toBeInTheDocument();
    expect(screen.getByText("poster.png")).toBeInTheDocument();

    // The image is now pending, but the form still requires a category, event
    // date, and deadline before it can be published.
    expect(submit).toBeDisabled();
  });
});
