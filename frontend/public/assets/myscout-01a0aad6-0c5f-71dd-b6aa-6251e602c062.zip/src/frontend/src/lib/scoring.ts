import type { FactorRatings, Opportunity } from "@/backend";

// The 10 weighted rating factors. Each factor is rated 0-5 with harsh scoring
// (5.0 is rare). Weights sum to 1.0 and match the MyScout reference:
//   Uni Application Value 20%, Skill Development 15%, Worth Your Time 15%,
//   Recognition 12%, Leadership 10%, Networking 8%, Difficulty 5%,
//   Time Commitment 5%, Price/Value 5%, Relevance 5%.
export const scoreWeights: Record<keyof FactorRatings, number> = {
  uniApplicationValue: 0.2,
  skillDevelopment: 0.15,
  worthYourTime: 0.15,
  recognition: 0.12,
  leadership: 0.1,
  networking: 0.08,
  difficulty: 0.05,
  timeCommitment: 0.05,
  priceValue: 0.05,
  relevance: 0.05,
};

export const factorOrder: Array<keyof FactorRatings> = [
  "uniApplicationValue",
  "skillDevelopment",
  "worthYourTime",
  "recognition",
  "leadership",
  "networking",
  "difficulty",
  "timeCommitment",
  "priceValue",
  "relevance",
];

export const factorLabels: Record<keyof FactorRatings, string> = {
  uniApplicationValue: "University application value",
  skillDevelopment: "Skill development",
  worthYourTime: "Worth your time",
  recognition: "Recognition / reputation",
  leadership: "Leadership potential",
  networking: "Networking",
  difficulty: "Difficulty / challenge",
  timeCommitment: "Time commitment",
  priceValue: "Price / value",
  relevance: "Relevance to interests",
};

/**
 * Compute the weighted overall score (0-5) from an opportunity's factor
 * ratings, rounded to one decimal with harsh scoring. Factor ratings arrive
 * from the backend as bigints in the 0-5 range.
 */
export function getOverallScore(
  opportunity: Pick<Opportunity, "factorRatings">,
): number {
  const weighted = factorOrder.reduce(
    (total, factor) =>
      total + Number(opportunity.factorRatings[factor]) * scoreWeights[factor],
    0,
  );
  return Math.round(weighted * 10) / 10;
}

/**
 * Color-code a score badge: teal for strong (>= 4.5), terracotta for solid
 * (>= 4.0), red for weak (< 4.0). Harsh scoring keeps 5.0 rare.
 */
export function getScoreColor(score: number): string {
  if (score >= 4.5) return "text-accent";
  if (score >= 4.0) return "text-primary";
  return "text-destructive";
}
