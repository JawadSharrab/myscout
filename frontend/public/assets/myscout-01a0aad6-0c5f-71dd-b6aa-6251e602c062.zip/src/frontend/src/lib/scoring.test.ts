import type { FactorRatings } from "@/backend";
import { getOverallScore, getScoreColor, scoreWeights } from "@/lib/scoring";
import { describe, expect, it } from "vitest";

const allFives: FactorRatings = {
  uniApplicationValue: 5,
  skillDevelopment: 5,
  worthYourTime: 5,
  recognition: 5,
  leadership: 5,
  networking: 5,
  difficulty: 5,
  timeCommitment: 5,
  priceValue: 5,
  relevance: 5,
};

const allZeros: FactorRatings = {
  uniApplicationValue: 0,
  skillDevelopment: 0,
  worthYourTime: 0,
  recognition: 0,
  leadership: 0,
  networking: 0,
  difficulty: 0,
  timeCommitment: 0,
  priceValue: 0,
  relevance: 0,
};

describe("getOverallScore", () => {
  it("weights the 10 factors and rounds to one decimal", () => {
    // Weights sum to 1.0.
    const total = Object.values(scoreWeights).reduce((a, b) => a + b, 0);
    expect(total).toBeCloseTo(1.0, 5);

    // All 5s -> 5.0.
    expect(getOverallScore({ factorRatings: allFives })).toBe(5.0);
    // All 0s -> 0.0.
    expect(getOverallScore({ factorRatings: allZeros })).toBe(0.0);
  });

  it("applies harsh scoring so a perfect 5.0 is rare", () => {
    // A strong but imperfect profile should not round up to 5.0.
    const strong: FactorRatings = {
      uniApplicationValue: 4.8,
      skillDevelopment: 4.7,
      worthYourTime: 4.6,
      recognition: 4.5,
      leadership: 4.4,
      networking: 4.5,
      difficulty: 4.0,
      timeCommitment: 4.0,
      priceValue: 4.5,
      relevance: 4.6,
    };
    const score = getOverallScore({ factorRatings: strong });
    expect(score).toBeLessThan(5.0);
    expect(Number.isInteger(score * 10)).toBe(true);
  });
});

describe("getScoreColor", () => {
  it("returns teal for strong, terracotta for solid, red for weak", () => {
    expect(getScoreColor(4.5)).toBe("text-accent");
    expect(getScoreColor(4.0)).toBe("text-primary");
    expect(getScoreColor(3.9)).toBe("text-destructive");
  });
});
