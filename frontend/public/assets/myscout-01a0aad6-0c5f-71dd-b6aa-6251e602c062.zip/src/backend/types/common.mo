import Principal "mo:core/Principal";

module {
  /// A user's identity, derived from their Internet Identity principal.
  public type UserId = Principal;

  /// Nanoseconds since the Unix epoch (matches `Time.now()`).
  public type Timestamp = Int;

  /// Numeric identifier for an opportunity.
  public type OpportunityId = Nat;
};
