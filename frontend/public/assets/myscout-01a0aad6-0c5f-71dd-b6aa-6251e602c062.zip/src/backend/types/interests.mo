import Opportunity "../types/opportunity";

module {
  /// A user's selected interest categories (multi-select, can be skipped).
  public type InterestSelection = [Opportunity.Category];
};
