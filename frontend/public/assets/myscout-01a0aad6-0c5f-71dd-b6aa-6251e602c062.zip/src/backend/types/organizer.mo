module {
  /// Profile for a user who registers as an event organizer.
  public type OrganizerProfile = {
    name : Text;
    contactEmail : Text;
    organization : Text;
  };
};
