import List "mo:core/List";
import Map "mo:core/Map";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/opportunity";
import OrganizerTypes "../types/organizer";
import Common "../types/common";
import OrganizerLib "../lib/organizer";

mixin (
  accessControlState : AccessControl.AccessControlState,
  opportunities : List.List<Types.Opportunity>,
  organizers : Map.Map<Common.UserId, OrganizerTypes.OrganizerProfile>,
  opportunityImages : Map.Map<Common.OpportunityId, [Storage.ExternalBlob]>,
) {
  /// Register the caller as an event organizer. Requires a signed-in caller.
  public shared ({ caller }) func createOrganizerAccount(profile : OrganizerTypes.OrganizerProfile) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can register as an organizer");
    };
    OrganizerLib.createOrganizerAccount(organizers, caller, profile);
  };

  /// Return the caller's organizer profile, if any. Requires a signed-in caller.
  public query ({ caller }) func getCallerOrganizerProfile() : async ?OrganizerTypes.OrganizerProfile {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can view their organizer profile");
    };
    OrganizerLib.getOrganizerProfile(organizers, caller);
  };

  /// List a new opportunity with at least one image. Requires an organizer role.
  public shared ({ caller }) func listOpportunity(opportunity : Types.NewOpportunity) : async Common.OpportunityId {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can list opportunities");
    };
    let profile = OrganizerLib.getOrganizerProfile(organizers, caller)
      ?? Runtime.trap("Unauthorized: You must register as an organizer before listing opportunities");
    let id = OrganizerLib.nextOpportunityId(opportunities);
    opportunities.add(OrganizerLib.toOpportunity(opportunity, id, profile.name));
    opportunityImages.add(id, opportunity.images);
    id;
  };

  /// Return the uploaded images for an opportunity. Public.
  public query func getOpportunityImages(id : Common.OpportunityId) : async [Storage.ExternalBlob] {
    OrganizerLib.getImages(opportunityImages, id);
  };
};
