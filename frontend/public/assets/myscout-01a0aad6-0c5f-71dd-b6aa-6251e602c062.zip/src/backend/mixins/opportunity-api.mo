import List "mo:core/List";
import Map "mo:core/Map";
import Set "mo:core/Set";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/opportunity";
import Common "../types/common";
import OpportunityLib "../lib/opportunity";

mixin (
  accessControlState : AccessControl.AccessControlState,
  opportunities : List.List<Types.Opportunity>,
  savedLists : Map.Map<Common.UserId, Set.Set<Common.OpportunityId>>,
  interests : Map.Map<Common.UserId, [Types.Category]>,
  organizers : Map.Map<Common.UserId, Types.OrganizerProfile>,
  opportunityImages : Map.Map<Common.OpportunityId, [Storage.ExternalBlob]>,
) {
  /// Return the full opportunity catalog. Public; no sign-in required.
  public query func getCatalog() : async [Types.Opportunity] {
    OpportunityLib.listOpportunities(opportunities);
  };

  /// Look up a single opportunity by id. Public.
  public query func getOpportunity(id : Common.OpportunityId) : async ?Types.Opportunity {
    OpportunityLib.getOpportunity(opportunities, id);
  };

  /// Return the 19 opportunity categories. Public.
  public query func getCategories() : async [Types.Category] {
    OpportunityLib.getCategories();
  };

  /// Search opportunities by keyword across name, organizer, and description. Public.
  public query func searchOpportunities(keyword : Text) : async [Types.Opportunity] {
    OpportunityLib.searchOpportunities(opportunities, keyword);
  };

  /// Filter opportunities by category, cost, distance, and status. Public.
  public query func filterOpportunities(filter : Types.OpportunityFilter) : async [Types.Opportunity] {
    OpportunityLib.filterOpportunities(opportunities, filter);
  };

  /// Return opportunities ordered by the given recommendation mode. Public.
  public query func recommend(mode : Types.RecommendationMode) : async [Types.Opportunity] {
    OpportunityLib.recommend(opportunities, mode);
  };

  /// Save an opportunity to the caller's saved list. Requires a signed-in caller.
  public shared ({ caller }) func saveOpportunity(id : Common.OpportunityId) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can save opportunities");
    };
    let current = switch (savedLists.get(caller)) {
      case (?s) s;
      case null Set.empty<Common.OpportunityId>();
    };
    current.add(id);
    savedLists.add(caller, current);
  };

  /// Remove an opportunity from the caller's saved list. Requires a signed-in caller.
  public shared ({ caller }) func unsaveOpportunity(id : Common.OpportunityId) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can unsave opportunities");
    };
    let current = switch (savedLists.get(caller)) {
      case (?s) s;
      case null Set.empty<Common.OpportunityId>();
    };
    current.remove(id);
    savedLists.add(caller, current);
  };

  /// Return the caller's saved opportunities. Requires a signed-in caller.
  public query ({ caller }) func getSavedOpportunities() : async [Types.Opportunity] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can view saved opportunities");
    };
    let saved = switch (savedLists.get(caller)) {
      case (?s) s;
      case null Set.empty<Common.OpportunityId>();
    };
    opportunities.toArray().filter(func o = saved.contains(o.id));
  };

  /// Return the per-factor rating breakdown for an opportunity. Public.
  public query func getRatingExplanation(id : Common.OpportunityId) : async ?Types.RatingExplanation {
    switch (OpportunityLib.getOpportunity(opportunities, id)) {
      case (?o) ?OpportunityLib.getRatingExplanation(o.factorRatings);
      case null null;
    };
  };
};
