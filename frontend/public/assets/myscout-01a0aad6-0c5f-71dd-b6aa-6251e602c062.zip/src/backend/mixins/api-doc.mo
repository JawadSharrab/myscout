mixin () {
  public query func getApiDoc() : async Text {
    "# MyScout Backend API

MyScout is a student opportunity-discovery platform for Amman, Jordan. This
backend serves the opportunity catalog, filtering, recommendation modes,
per-user saved lists, the structured 10-factor weighted rating system, per-user
interest personalization, account management, and event-organizer listing.

## Public methods

- `getCatalog() : async [Opportunity]` — the full opportunity catalog.
- `getOpportunity(id : Nat) : async ?Opportunity` — a single opportunity by id.
- `getCategories() : async [Category]` — the 19 opportunity categories.
- `searchOpportunities(keyword : Text) : async [Opportunity]` — keyword search
  across name, organizer, and description.
- `filterOpportunities(filter : OpportunityFilter) : async [Opportunity]` —
  filter by category, cost (free/paid), distance, and status.
- `recommend(mode : RecommendationMode) : async [Opportunity]` — order the
  catalog by a recommendation mode: highest-rated, closing-soon, closest,
  university, best-value, or skills.
- `saveOpportunity(id : Nat) : async ()` — save an opportunity to the caller's
  saved list.
- `unsaveOpportunity(id : Nat) : async ()` — remove an opportunity from the
  caller's saved list.
- `getSavedOpportunities() : async [Opportunity]` — the caller's saved
  opportunities.
- `getRatingExplanation(id : Nat) : async ?RatingExplanation` — the per-factor
  breakdown of an opportunity's overall score.
- `getOpportunityImages(id : Nat) : async [ExternalBlob]` — the uploaded images
  for an opportunity (empty for seeded/prototype listings).
- `execute(query : Text) : async Text` — run a JSON OQL query over the exposed
  entities (opportunity, interest, organizer). See the OQL schema below.
- `schema() : async Text` — the OQL schema describing the queryable entities and
  their fields.
- `assignCallerUserRole(user : Principal, role : UserRole) : async ()` — assign
  a role to a user. Admin-only.
- `getCallerUserRole() : async UserRole` — the caller's current role
  (`#admin`, `#user`, or `#guest`).
- `isCallerAdmin() : async Bool` — whether the caller is an admin.

## Interests and personalization

- `getInterests() : async [Category]` — the caller's selected interest
  categories (multi-select).
- `setInterests(selected : [Category]) : async ()` — replace the caller's
  selected interest categories. Multi-select; passing an empty list clears them.
- `recommendByInterests() : async [Opportunity]` — re-rank/surface the catalog
  by the caller's interests.
- `filterByInterests() : async [Opportunity]` — filter the catalog to
  opportunities matching the caller's interests.

## Account management

- `deleteAccount(confirmation : Text) : async ()` — permanently delete the
  caller's account, wiping their saved opportunities, interests, and organizer
  profile. Requires the confirmation string `\"DELETE\"`.

## Event-organizer listing

- `createOrganizerAccount(profile : OrganizerProfile) : async ()` — register the
  caller as an event organizer.
- `getCallerOrganizerProfile() : async ?OrganizerProfile` — the caller's
  organizer profile, or `null` if not registered.
- `listOpportunity(opportunity : NewOpportunity) : async Nat` — list a new
  opportunity with at least one uploaded image. Requires an organizer role. The
  returned id is the new opportunity's id; the listing appears in the catalog.

## Authentication and authorization

The app uses Internet Identity. Anonymous callers are treated as guests.

- Public read methods (`getCatalog`, `getOpportunity`, `getCategories`,
  `searchOpportunities`, `filterOpportunities`, `recommend`,
  `getRatingExplanation`, `getOpportunityImages`, `schema`, `execute`) require
  no sign-in.
- `saveOpportunity`, `unsaveOpportunity`, `getSavedOpportunities`,
  `getInterests`, `setInterests`, `recommendByInterests`, `filterByInterests`,
  `deleteAccount`, `createOrganizerAccount`, and `getCallerOrganizerProfile`
  require a signed-in (non-anonymous) caller. Anonymous callers are rejected on
  these endpoints.
- `listOpportunity` additionally requires the caller to be a registered
  organizer (created via `createOrganizerAccount`).
- `assignCallerUserRole` is admin-only.

### Registration prerequisite

Role-guarded endpoints (the signed-in methods above, guarded queries included)
require the caller to be registered in the access-control state. Registration
happens automatically when a caller signs in through the app's own frontend:
the first signed-in caller is granted the `#admin` role, and every subsequent
caller is granted `#user`. A direct API caller who has never signed in through
the frontend is unregistered and is rejected on guarded endpoints with an
authorization trap (for example `\"Unauthorized: Only signed-in users can save
opportunities\"`). Anonymous callers are likewise rejected on guarded endpoints.
A caller can be unregistered even when it belongs to the app's owner, because
registration only occurs on sign-in through the app's frontend; a signed-in
caller derived against a different origin is a different principal than the one
the frontend registered.

The app's frontend pins an Internet Identity derivation origin, published at
`/.well-known/ii-derivation-origin` when available. An agent already holding
the user's Internet Identity authorization derives the correct per-app
principal against that origin (for example
`icp identity link web <name> --app <host>`). Such a delegation acts with the
user's full authority in this app until it expires.

## Units and encodings

- `id` is a `Nat` unique per opportunity.
- `date` and `deadline` are `Int` nanoseconds since the Unix epoch
  (matching `Time.now()`).
- `distanceKm` is a `Float` in kilometres.
- `factorRatings` holds 10 `Float` factors each rated 0-5.
- `registrationUrl` and `instagramUrl` are optional `Text` URLs (`null` when
  absent).
- `status` is a variant: `#open`, `#closingSoon`, or `#closed`.
- `category` is one of 19 variants.
- `marker` is `{ x : Float; y : Float }` normalized map coordinates.
- `isPrototype` is a `Bool` flag for prototype/demo listings.
- `images` (in `NewOpportunity`) is an array of `ExternalBlob` references; at
  least one is required for organizer listings. Listing images are stored
  off-chain via the object-storage extension and fetched with
  `getOpportunityImages`.

## OQL query interface

`schema()` returns the discoverable entities and their fields. `execute(query)`
takes a JSON OQL query string and returns a JSON result. Three entities are
exposed:

- `opportunity` — the public catalog. Readable by anyone, including anonymous
  callers.
- `interest` — per-user interest selections, keyed by the owning user. A
  signed-in caller reads only their own rows.
- `organizer` — per-user organizer profiles, keyed by the owning user. A
  signed-in caller reads only their own rows.

## Rating system

The overall score is a weighted average of 10 factors, each rated 0-5:
Uni Application Value 20%, Skill Development 15%, Worth Your Time 15%,
Recognition 12%, Leadership 10%, Networking 8%, Difficulty 5%,
Time Commitment 5%, Price/Value 5%, Relevance 5%. The overall score is rounded
to one decimal with harsh scoring, so a 5.0 is rare.

## Lifecycle and status

`status` is derived from `deadline` relative to the current time: an
opportunity is `#open` while its deadline is comfortably in the future,
`#closingSoon` as the deadline approaches, and `#closed` once the deadline has
passed. The reference date is not hardcoded; status reflects current dates.

## Mutation retry safety

`saveOpportunity` and `unsaveOpportunity` are idempotent: saving an already
saved opportunity and unsaving one that is not saved are safe to repeat.
`setInterests` replaces the caller's full selection, so it is safe to repeat.
`deleteAccount` is destructive and irreversible: it permanently wipes the
caller's saved opportunities, interests, and organizer profile. `listOpportunity`
creates a new listing each call and is not idempotent. Saves, interests, and
organizer profiles persist per user across sessions, keyed by the caller's
principal.

## Errors, traps, and limits

- Calling a save/unsave/saved-list/interest/account/organizer method as an
  anonymous or unregistered caller traps with an authorization error.
- `listOpportunity` traps if the caller is not a registered organizer.
- `deleteAccount` traps if the confirmation string is not `\"DELETE\"`.
- `assignCallerUserRole` traps if the caller is not an admin.
- `getOpportunity` and `getRatingExplanation` return `null` for an unknown id.
- `execute` returns an error result for a malformed or invalid OQL query.
- The catalog is seeded with 42 prototype opportunities (12 curated + 30
  demo)."
  };
};
