import List "mo:core/List";
import Map "mo:core/Map";
import Set "mo:core/Set";
import Runtime "mo:core/Runtime";
import AccessControl "mo:caffeineai-authorization/access-control";
import Types "../types/opportunity";
import Common "../types/common";
import InterestsLib "../lib/interests";

mixin (
  accessControlState : AccessControl.AccessControlState,
  opportunities : List.List<Types.Opportunity>,
  savedLists : Map.Map<Common.UserId, Set.Set<Common.OpportunityId>>,
  interests : Map.Map<Common.UserId, [Types.Category]>,
  organizers : Map.Map<Common.UserId, Types.OrganizerProfile>,
) {
  /// Return the caller's selected interest categories. Requires a signed-in caller.
  public query ({ caller }) func getInterests() : async [Types.Category] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can view interests");
    };
    InterestsLib.getInterests(interests, caller);
  };

  /// Set the caller's selected interest categories (multi-select, replaces). Requires a signed-in caller.
  public shared ({ caller }) func setInterests(selected : [Types.Category]) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can set interests");
    };
    InterestsLib.setInterests(interests, caller, selected);
  };

  /// Re-rank/surface opportunities by the caller's interests. Requires a signed-in caller.
  public query ({ caller }) func recommendByInterests() : async [Types.Opportunity] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can get recommendations");
    };
    InterestsLib.recommendByInterests(opportunities, InterestsLib.getInterests(interests, caller));
  };

  /// Filter opportunities to those matching the caller's interests. Requires a signed-in caller.
  public query ({ caller }) func filterByInterests() : async [Types.Opportunity] {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can filter by interests");
    };
    InterestsLib.filterByInterests(opportunities, InterestsLib.getInterests(interests, caller));
  };

  /// Delete the caller's account, wiping saved opportunities, interests, and
  /// organizer profile. Requires a signed-in caller and the confirmation string "DELETE".
  public shared ({ caller }) func deleteAccount(confirmation : Text) : async () {
    if (not AccessControl.hasPermission(accessControlState, caller, #user)) {
      Runtime.trap("Unauthorized: Only signed-in users can delete their account");
    };
    if (confirmation != "DELETE") {
      Runtime.trap("Confirmation required: pass \"DELETE\" to delete your account");
    };
    InterestsLib.deleteAccount(savedLists, interests, organizers, caller);
  };
};
