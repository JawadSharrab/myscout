import List "mo:core/List";
import Map "mo:core/Map";
import Set "mo:core/Set";
import Float "mo:core/Float";
import Principal "mo:core/Principal";
import Types "../types/opportunity";
import Common "../types/common";

module {
  /// Return the caller's selected interest categories (empty if none set).
  public func getInterests(interests : Map.Map<Common.UserId, [Types.Category]>, caller : Common.UserId) : [Types.Category] {
    switch (interests.get(caller)) {
      case (?c) c;
      case null [];
    };
  };

  /// Set (replace) the caller's selected interest categories.
  public func setInterests(interests : Map.Map<Common.UserId, [Types.Category]>, caller : Common.UserId, selected : [Types.Category]) : () {
    interests.add(caller, selected);
  };

  /// A 0-1+ score for how well an opportunity matches the caller's interests:
  /// matching opportunities score 1.0 plus their relevance factor, so they
  /// surface above non-matching ones and rank by relevance within each group.
  func interestScore(o : Types.Opportunity, interests : [Types.Category]) : Float {
    let matched = interests.any(func c = c == o.category);
    if (matched) { 1.0 + o.factorRatings.relevance } else { o.factorRatings.relevance };
  };

  /// Re-rank/surface opportunities by the caller's interest categories.
  public func recommendByInterests(opportunities : List.List<Types.Opportunity>, interests : [Types.Category]) : [Types.Opportunity] {
    let arr = opportunities.toArray();
    arr.sort(func (a, b) = Float.compare(interestScore(b, interests), interestScore(a, interests)));
  };

  /// Filter opportunities to those matching the caller's interest categories.
  public func filterByInterests(opportunities : List.List<Types.Opportunity>, interests : [Types.Category]) : [Types.Opportunity] {
    opportunities.toArray().filter(func o = interests.any(func c = c == o.category));
  };

  /// Wipe all of a user's personal data: saved opportunities, interests, and
  /// organizer profile. Called after the caller confirms account deletion.
  public func deleteAccount(
    savedLists : Map.Map<Common.UserId, Set.Set<Common.OpportunityId>>,
    interests : Map.Map<Common.UserId, [Types.Category]>,
    organizers : Map.Map<Common.UserId, Types.OrganizerProfile>,
    caller : Common.UserId,
  ) : () {
    savedLists.remove(caller);
    interests.remove(caller);
    organizers.remove(caller);
  };
};
