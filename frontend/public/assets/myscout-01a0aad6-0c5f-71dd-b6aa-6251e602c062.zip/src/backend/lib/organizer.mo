import List "mo:core/List";
import Map "mo:core/Map";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "../types/opportunity";
import OrganizerTypes "../types/organizer";
import Common "../types/common";

module {
  /// Register the caller as an event organizer.
  public func createOrganizerAccount(
    organizers : Map.Map<Common.UserId, OrganizerTypes.OrganizerProfile>,
    caller : Common.UserId,
    profile : OrganizerTypes.OrganizerProfile,
  ) {
    organizers.add(caller, profile);
  };

  /// Return the caller's organizer profile, if any.
  public func getOrganizerProfile(
    organizers : Map.Map<Common.UserId, OrganizerTypes.OrganizerProfile>,
    caller : Common.UserId,
  ) : ?OrganizerTypes.OrganizerProfile {
    organizers.get(caller);
  };

  /// Compute the next opportunity id (max existing id + 1).
  public func nextOpportunityId(opportunities : List.List<Types.Opportunity>) : Common.OpportunityId {
    var maxId = 0;
    for (o in opportunities.values()) {
      if (o.id >= maxId) { maxId := o.id + 1 };
    };
    maxId;
  };

  /// Convert a NewOpportunity payload into a full Opportunity record.
  /// Listing images are stored separately (keyed by opportunity id).
  public func toOpportunity(
    newOpp : Types.NewOpportunity,
    id : Common.OpportunityId,
    organizerName : Text,
  ) : Types.Opportunity {
    {
      id;
      name = newOpp.name;
      organizer = organizerName;
      category = newOpp.category;
      description = newOpp.description;
      venue = newOpp.venue;
      location = newOpp.location;
      date = newOpp.date;
      duration = newOpp.duration;
      ageRange = newOpp.ageRange;
      fee = newOpp.fee;
      deadline = newOpp.deadline;
      registrationUrl = newOpp.registrationUrl;
      instagramUrl = newOpp.instagramUrl;
      factorRatings = {
        uniApplicationValue = 0.0;
        skillDevelopment = 0.0;
        worthYourTime = 0.0;
        recognition = 0.0;
        leadership = 0.0;
        networking = 0.0;
        difficulty = 0.0;
        timeCommitment = 0.0;
        priceValue = 0.0;
        relevance = 0.0;
      };
      status = #open;
      distanceKm = 0.0;
      marker = { x = 0.0; y = 0.0 };
      isPrototype = false;
    };
  };

  /// Return the uploaded images for an opportunity.
  public func getImages(
    opportunityImages : Map.Map<Common.OpportunityId, [Storage.ExternalBlob]>,
    id : Common.OpportunityId,
  ) : [Storage.ExternalBlob] {
    switch (opportunityImages.get(id)) {
      case (?imgs) imgs;
      case null [];
    };
  };
};
