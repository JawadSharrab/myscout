import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import MixinObjectStorage "mo:caffeineai-object-storage/Mixin";
import Expose "mo:caffeineai-oql/Expose";
import OQL "mo:caffeineai-oql";
import Entity "mo:caffeineai-oql/Entity";
import NatValue "mo:caffeineai-oql/NatValue";
import IntValue "mo:caffeineai-oql/IntValue";
import TextValue "mo:caffeineai-oql/TextValue";
import FloatValue "mo:caffeineai-oql/FloatValue";
import PrincipalValue "mo:caffeineai-oql/PrincipalValue";
import List "mo:core/List";
import Map "mo:core/Map";
import Set "mo:core/Set";
import Principal "mo:core/Principal";
import Storage "mo:caffeineai-object-storage/Storage";
import Types "types/opportunity";
import Common "types/common";
import OpportunityApi "mixins/opportunity-api";
import InterestsApi "mixins/interests-api";
import OrganizerApi "mixins/organizer-api";
import ApiDoc "mixins/api-doc";

actor {
  let accessControlState : AccessControl.AccessControlState;
  let opportunities : List.List<Types.Opportunity>;
  let savedLists : Map.Map<Common.UserId, Set.Set<Common.OpportunityId>>;
  let interests : Map.Map<Common.UserId, [Types.Category]>;
  let organizers : Map.Map<Common.UserId, Types.OrganizerProfile>;
  let opportunityImages : Map.Map<Common.OpportunityId, [Storage.ExternalBlob]>;

  include MixinAuthorization(accessControlState, null);
  include MixinObjectStorage();
  include OpportunityApi(accessControlState, opportunities, savedLists, interests, organizers, opportunityImages);
  include InterestsApi(accessControlState, opportunities, savedLists, interests, organizers);
  include OrganizerApi(accessControlState, opportunities, organizers, opportunityImages);
  include ApiDoc();

  func categoryToText(c : Types.Category) : Text {
    switch (c) {
      case (#academic) "academic";
      case (#arts) "arts";
      case (#athletics) "athletics";
      case (#business) "business";
      case (#coding) "coding";
      case (#community) "community";
      case (#competition) "competition";
      case (#conference) "conference";
      case (#creative) "creative";
      case (#culture) "culture";
      case (#debate) "debate";
      case (#design) "design";
      case (#entrepreneurship) "entrepreneurship";
      case (#environment) "environment";
      case (#health) "health";
      case (#internship) "internship";
      case (#leadership) "leadership";
      case (#scholarship) "scholarship";
      case (#volunteering) "volunteering";
    };
  };

  func statusToText(s : Types.Status) : Text {
    switch (s) {
      case (#open) "open";
      case (#closingSoon) "closing-soon";
      case (#closed) "closed";
    };
  };

  func categoriesToText(cs : [Types.Category]) : Text {
    cs.map(categoryToText).values().join(",");
  };

  transient let anyP = Principal.fromText("aaaaa-aa");

  include Expose({
    entities = [
      OQL.Entity.manual<Types.Opportunity>("opportunity", func () = opportunities.values(), "Opportunity", "id")
        .sample({
          id = 0;
          name = "";
          organizer = "";
          category = #academic;
          description = "";
          venue = "";
          location = "";
          date = 0;
          duration = "";
          ageRange = "";
          fee = "";
          deadline = 0;
          registrationUrl = null;
          instagramUrl = null;
          factorRatings = {
            uniApplicationValue = 0.0;
            skillDevelopment = 0.0;
            worthYourTime = 0.0;
            recognition = 0.0;
            leadership = 0.0;
            networking = 0.0;
            difficulty = 0.0;
            timeCommitment = 0.0;
            priceValue = 0.0;
            relevance = 0.0;
          };
          status = #open;
          distanceKm = 0.0;
          marker = { x = 0.0; y = 0.0 };
          isPrototype = false;
        })
        .payload("id", func o = o.id)
        .payload("name", func o = o.name)
        .payload("organizer", func o = o.organizer)
        .payload("category", func o = categoryToText(o.category))
        .payload("status", func o = statusToText(o.status))
        .payload("fee", func o = o.fee)
        .payload("distanceKm", func o = o.distanceKm)
        .payload("date", func o = o.date)
        .payload("deadline", func o = o.deadline)
        .public_()
        .build(),
      OQL.Entity.manual<(Common.UserId, [Types.Category])>("interest", func () = interests.entries(), "Interest", "user")
        .sample((anyP, [#academic]))
        .payload("user", func ((u, _)) = u)
        .payload("categories", func ((_, c)) = categoriesToText(c))
        .ownedBy("user")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Common.UserId, Types.OrganizerProfile)>("organizer", func () = organizers.entries(), "Organizer", "user")
        .sample((anyP, { name = ""; contactEmail = ""; organization = "" }))
        .payload("user", func ((u, _)) = u)
        .payload("name", func ((_, p)) = p.name)
        .payload("contactEmail", func ((_, p)) = p.contactEmail)
        .payload("organization", func ((_, p)) = p.organization)
        .ownedBy("user")
        .controllerOrScoped()
        .build(),
    ];
  });
};
