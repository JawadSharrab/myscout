import List "mo:core/List";
import Map "mo:core/Map";
import Set "mo:core/Set";
import Principal "mo:core/Principal";
import AccessControl "mo:caffeineai-authorization/access-control";

module {
  type OpportunityId = Nat;
  type UserId = Principal;

  type Category = {
    #academic;
    #arts;
    #athletics;
    #business;
    #coding;
    #community;
    #competition;
    #conference;
    #creative;
    #culture;
    #debate;
    #design;
    #entrepreneurship;
    #environment;
    #health;
    #internship;
    #leadership;
    #scholarship;
    #volunteering;
  };

  type Status = {
    #open;
    #closingSoon;
    #closed;
  };

  type FactorRatings = {
    uniApplicationValue : Float;
    skillDevelopment : Float;
    worthYourTime : Float;
    recognition : Float;
    leadership : Float;
    networking : Float;
    difficulty : Float;
    timeCommitment : Float;
    priceValue : Float;
    relevance : Float;
  };

  type Marker = {
    x : Float;
    y : Float;
  };

  type Opportunity = {
    id : OpportunityId;
    name : Text;
    organizer : Text;
    category : Category;
    description : Text;
    venue : Text;
    location : Text;
    date : Int;
    duration : Text;
    ageRange : Text;
    fee : Text;
    deadline : Int;
    registrationUrl : ?Text;
    instagramUrl : ?Text;
    factorRatings : FactorRatings;
    status : Status;
    distanceKm : Float;
    marker : Marker;
    isPrototype : Bool;
  };

  type OrganizerProfile = {
    name : Text;
    contactEmail : Text;
    organization : Text;
  };

  type OldActor = {
    accessControlState : AccessControl.AccessControlState;
    opportunities : List.List<Opportunity>;
    savedLists : Map.Map<UserId, Set.Set<OpportunityId>>;
  };

  type NewActor = {
    accessControlState : AccessControl.AccessControlState;
    opportunities : List.List<Opportunity>;
    savedLists : Map.Map<UserId, Set.Set<OpportunityId>>;
    interests : Map.Map<UserId, [Category]>;
    organizers : Map.Map<UserId, OrganizerProfile>;
    opportunityImages : Map.Map<OpportunityId, [Blob]>;
  };

  public func migration(old : OldActor) : NewActor {
    {
      accessControlState = old.accessControlState;
      opportunities = old.opportunities;
      savedLists = old.savedLists;
      interests = Map.empty();
      organizers = Map.empty();
      opportunityImages = Map.empty();
    };
  };
};
