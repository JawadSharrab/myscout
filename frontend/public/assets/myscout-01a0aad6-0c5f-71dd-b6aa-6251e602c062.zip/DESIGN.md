# Design Brief

## Direction

Amman Limestone Editorial — the restored MyScout hero (cream, bold serif, sky-blue accent, navy featured card) over the existing warm discovery system, plus a compact tabbed layout.

## Tone

Editorial, confident, place-specific — a high-contrast serif hero on warm cream with a deep-navy featured card and a bright sky-blue accent, favoring clarity over decoration.

## Differentiation

The old-look hero anchors the brand: a bold serif headline with "worth doing." in bright sky blue beside a floating navy featured card with pill filter chips — unmistakable and anti-generic.

## Color Palette

| Token      | OKLCH (light) | Role                       |
| ---------- | ------------- | -------------------------- |
| background | 0.965 0.02 85 | warm cream base            |
| foreground | 0.2 0.03 50   | deep warm charcoal text    |
| card       | 0.99 0.012 85 | elevated card surface      |
| primary    | 0.5 0.16 40   | terracotta CTA / active    |
| navy       | 0.27 0.05 265 | featured card surface      |
| accent     | 0.64 0.17 245 | bright sky blue highlight  |
| muted      | 0.93 0.02 85  | secondary surfaces         |
| success    | 0.55 0.16 150 | open / positive status     |
| warning    | 0.7 0.15 85   | closing-soon status        |
| destructive| 0.55 0.22 25  | closed / errors            |

## Typography

- Display: Fraunces — hero headline, section headings, opportunity titles (serif editorial)
- Body: DM Sans — paragraphs, UI labels, card text
- Mono: JetBrains Mono — scores, distances, numeric metadata
- Scale: hero `text-5xl md:text-7xl font-bold tracking-tight`, h2 `text-2xl md:text-3xl font-bold tracking-tight`, label `text-xs font-semibold tracking-widest uppercase`, body `text-base`

## Elevation & Depth

Card-based hierarchy with soft warm `shadow-subtle` resting state and `shadow-elevated` on hover; the navy featured card uses `shadow-elevated` plus a navy gradient for depth.

## Structural Zones

| Zone    | Background  | Border   | Notes                              |
| ------- | ----------- | -------- | ---------------------------------- |
| Header  | bg-card     | border-b | sticky, compact, elevated surface  |
| Hero    | bg-background | —      | cream, split text + navy card      |
| Tabs    | bg-card     | border   | For you / Explore / Saved, compact |
| Content | bg-background | —      | alternating bg-muted/30 sections   |
| Footer  | bg-muted/40 | border-t | muted, low emphasis                |

## Spacing & Rhythm

Compact tabbed layout to reduce scrolling: tight tab bar under the hero, content grouped into tabs/sections; 4px micro-spacing grid, cards in 3-col grids collapsing to 1 on mobile, 2rem container padding.

## Component Patterns

- Buttons: rounded-full pills, terracotta primary, navy on featured card, hover darkens
- Cards: rounded-2xl, bg-card, shadow-subtle → shadow-elevated on hover; featured card bg-navy text-navy-foreground
- Badges: rounded-full pill chips, sky-blue active state, color-coded by status

## Motion

- Entrance: hero-rise 0.6s on hero card, fade-in 0.35s on list/tab mount
- Hover: card lift + shadow transition 0.3s
- Decorative: marker-pulse on active map markers

## Constraints

- Token-only styling; no raw color literals in components
- Harsh scoring: 5.0 rare, overall score rounded to one decimal
- Restore old hero visual only; keep rest of current layout
- Compact, tabbed, less scroll-heavy homepage
- doNotBuild: video upload for event/opportunity listings

## Signature Detail

The bold serif headline with "worth doing." set in bright sky blue, paired with a floating navy featured card and pill filter chips — the restored hero that makes MyScout instantly recognizable.
